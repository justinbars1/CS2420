package assignment10;

public class testPrime {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		int large = 390456;
		int small = 36;
		int med = 43123;
		
		int index = primeNumber.nextPrime(small);
		System.out.println(index);
		index = primeNumber.nextPrime(large);
		System.out.println(index);
		index = primeNumber.nextPrime(med);
		System.out.println(index);		
	}

}
