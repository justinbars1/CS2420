
package assignment10;
/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public class GoodHashFunctor implements HashFunctor{

	
	public int hash(String item) {
		int hash = 0;
		char[] word = item.toCharArray();
		for(char c: word)
		{
			hash = hash + c;
		}
		return hash;
	}

}
