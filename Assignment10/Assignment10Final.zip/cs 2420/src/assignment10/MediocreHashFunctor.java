package assignment10;
/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public class MediocreHashFunctor implements HashFunctor {

	
	public int hash(String item) {
		int hash = 0;
		int prime = 11;
		char[] word = item.toCharArray();
		if (word.length <= 2)
		{
			hash = word[0] * prime;
		}
		else if (word.length == 3)
		{
			hash = word[1] * prime;
		}
		else
		{
			hash = word[3] * prime;
		}
		return hash;
	}

}
