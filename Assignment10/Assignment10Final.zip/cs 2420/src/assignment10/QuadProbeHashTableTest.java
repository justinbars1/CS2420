package assignment10;

import static org.junit.Assert.*;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class QuadProbeHashTableTest extends TestCase {
	QuadProbeHashTable table;
	QuadProbeHashTable tableSmall;
	QuadProbeHashTable tableEmpty;
	@Before
	public void setUp() throws Exception {
		
	
		tableSmall =  new QuadProbeHashTable(10, new GoodHashFunctor());
		tableSmall.add("one");
		tableEmpty =  new QuadProbeHashTable(10, new GoodHashFunctor());
		table =  new QuadProbeHashTable(10, new GoodHashFunctor());
		ArrayList<String> words = readWordsFromFile("100words.txt");
				for(String s : words)
					table.add(s);
	}

	@Test
	public void testSingleItemList() {
		assertEquals(1, tableSmall.itemsInArray);
		tableSmall.clear();
		assertEquals(0, tableSmall.itemsInArray);
		tableSmall.add("one");
		assertEquals(true, tableSmall.contains("one"));
		assertEquals(false, tableSmall.contains("two"));
		LinkedList<String> s = new LinkedList<String>();
		s.add("one");
		assertEquals(true, tableSmall.containsAll(s));
		s.add("two");
		assertEquals(false, tableSmall.containsAll(s));
		tableSmall.clear();
		assertEquals(true, tableSmall.isEmpty());
	}
	@Test
	public void testEmptyList() {
		assertEquals(0, tableEmpty.itemsInArray);
		tableEmpty.clear();
		assertEquals(0, tableEmpty.itemsInArray);
		
		assertEquals(false, tableEmpty.contains("one"));
		
		LinkedList<String> s = new LinkedList<String>();
		assertEquals(true, tableEmpty.containsAll(s));
		s.add("one");
		assertEquals(false, tableEmpty.containsAll(s));
		s.add("two");
		assertEquals(false, tableEmpty.containsAll(s));
		
	}
	@Test
	public void testLargeList() {
		assertEquals(100, table.itemsInArray);
		table.add("testingString");
		assertEquals(true, table.contains("testingString"));
		assertEquals(false, table.contains("two"));
		LinkedList<String> s = new LinkedList<String>();
		s.add("touch");
		s.add("tax");
		s.add("payment");
		assertEquals(true, table.containsAll(s));
		s.add("anotherTestString");
		assertEquals(false, table.containsAll(s));
		assertEquals(true, table.contains(null));
		table.clear();
		assertEquals(0, table.itemsInArray);
		assertEquals(true, table.isEmpty());
		
	}
	
	private static ArrayList<String> readWordsFromFile(String filename)
	{
		ArrayList<String> retVal = new ArrayList<String>();
		try 
		{
			BufferedReader input = new BufferedReader(new FileReader(filename));

			while(input.ready())
			{
				retVal.add(input.readLine());
			}
			input.close();
		} 
		catch (FileNotFoundException e) 
		{	
			e.printStackTrace();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		return retVal;
	}

}
