package assignment10;

public class primeNumber {

	/**
	 * @param args
	 */

	public static int nextPrime(int arg0) {
		int index = arg0;
		boolean prime = false;
		if (index > 270229) {
			prime = isPrime(index);
			while(!prime){
				index++;
				prime = isPrime(index);
			}
			return index;
		}
		if (index <= 270229)
			index = getPrime(index);

		return index;

	}

	private static boolean isPrime(int num) {
		boolean prime = true;
		int limit = (int) Math.sqrt(num);

		for (int i = 2; i <= limit; i++) {
			if (num % i == 0) {
				prime = false;
				break;
			}
		}
		return prime;
	}

	private static int getPrime(int target) {

		if (target == 2)
			return 3;
		if (target <= 5)
			return 5;
		if (target <= 7)
			return 7;
		if (target <= 11)
			return 11;
		if (target <= 13)
			return 13;
		if (target <= 17)
			return 17;
		if (target <= 19)
			return 19;
		if (target <= 23)
			return 23;
		if (target <= 29)
			return 29;
		if (target <= 31)
			return 31;
		if (target <= 37)
			return 37;
		if (target <= 41)
			return 41;
		if (target <= 43)
			return 43;
		if (target <= 47)
			return 47;
		if (target <= 53)
			return 53;
		if (target <= 59)
			return 59;
		if (target <= 61)
			return 61;
		if (target <= 67)
			return 67;
		if (target <= 71)
			return 71;
		if (target <= 73)
			return 73;
		if (target <= 79)
			return 79;
		if (target <= 83)
			return 83;
		if (target <= 97)
			return 97;
		if (target <= 101)
			return 101;
		if (target <= 103)
			return 103;
		if (target <= 211)
			return 211;
		if (target <= 449)
			return 449;
		if (target <= 991)
			return 991;
		if (target <= 2099)
			return 2099;
		if (target <= 4211)
			return 4211;
		if (target <= 8443)
			return 8443;
		if (target <= 16889)
			return 16889;
		if (target <= 33773)
			return 33773;
		if (target <= 67559)
			return 67559;
		if (target <= 135119)
			return 135119;
		if (target <= 270229)
			return 270229;
		return -1;
	}

}
