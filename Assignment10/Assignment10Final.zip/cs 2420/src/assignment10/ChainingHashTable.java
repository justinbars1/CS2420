package assignment10;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public class ChainingHashTable implements Set<String> {
	
	private LinkedList<String>[] storage;
	int arraySize, itemsInArray;
	double loadFactor;
	private HashFunctor convert;
	int collisions = 0;
	
	@SuppressWarnings("unchecked")
	public ChainingHashTable (int capacity, HashFunctor functor)
	{
		
		storage = (LinkedList<String>[]) new LinkedList[capacity];
		arraySize = capacity;
		itemsInArray = 0;
		convert = functor;
	}
	public boolean add(String item) 
	{
		if(item == null)
			return true;
		int index = getIndex(item,storage);
		LinkedList<String> temp = storage[index];
		if (temp == null)
		{
			temp = new LinkedList<String>();
			temp.add(item);
			itemsInArray++;
			loadFactor = ((double)(itemsInArray))/((double)(arraySize));
			storage[index] = temp;
			
			
			
		}
		else if (!temp.contains(item))
		{
			if (temp.isEmpty() == false)
				collisions++;
			temp.add(item);
			itemsInArray++;
			loadFactor = ((double)(itemsInArray))/((double)(arraySize));
			storage[index] = temp;
		}
		

		
		if(loadFactor >= 0.5)
		{
			rehasher();
		}
		
		return true;
	}

	
	public boolean addAll(Collection<? extends String> items) {
		for (String s: items)
		{
			add(s);
		}
		return true;
	}

	
	@SuppressWarnings("unchecked")
	public void clear() {
		storage = (LinkedList<String>[]) new LinkedList[primeNumber.nextPrime(arraySize)];
		itemsInArray = 0;
		loadFactor = 0;
		collisions = 0;
	}

	
	public boolean contains(String item) {
		if(item == null)
			return true;
		LinkedList<String> temp = storage[this.getIndex(item, storage)];
		if (temp == null)
			return false;
		
		return (temp.contains(item));
	}

	
	public boolean containsAll(Collection<? extends String> items) {
		boolean allFound = true;
		for (String s: items)
		{
			if (!contains(s))
				allFound = false;
		}
		return allFound;
	}

	
	public boolean isEmpty() {
		
		return itemsInArray == 0;
	}

	
	public int size() {
		
		return itemsInArray;
	}
	private void rehasher(){
		
		
		ChainingHashTable temp = new ChainingHashTable(primeNumber.nextPrime(arraySize*2), convert);
		arraySize = temp.arraySize;
		for(LinkedList<String> s : storage)
		{
			if(s == null)
				continue;

			temp.addAll(s);
		}
		storage = temp.storage;
		loadFactor = temp.loadFactor;
			
	}
//	private int getIndex(LinkedList<String> item, LinkedList<String>[] temp){
//		String first = item.getFirst();
//		
//		return getIndex(first, temp);
//		
//	}
	private int getIndex(String item, LinkedList<String>[] temp){
		if(item == null)
			return 0;
		int hash = convert.hash(item);
		int index = hash%arraySize;
		while(index >= arraySize)
		{
		 index = index-arraySize;
		}
		
			
		return index;
		
	}
}
