package assignment10;


import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.math.BigInteger;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Random;

public class Timer {
    private static Random rand;
    public static void main(String[] args)
    {
        int size = 0;
        
        rand = new Random();
        rand.setSeed(System.currentTimeMillis());
        int randomInt = randomInt();
        int numberOfItems = 20000;
        
        QuadProbeHashTable tableGood = new QuadProbeHashTable(10, new GoodHashFunctor());
        QuadProbeHashTable tableMedium = new QuadProbeHashTable(10, new MediocreHashFunctor());
        QuadProbeHashTable tableBad = new QuadProbeHashTable(10, new BadHashFunctor());
		
//        for(String s : words)
//			tableGood.add(s);
//		for(String s : words)
//			tableMedium.add(s);
//		for(String s : words)
//			tableBad.add(s);

        
        
        for(size = 0; size <= 1000; size+=100)
        {
        long startTime, midpointTime, stopTime;
        ArrayList<String> words = new ArrayList<String>();
        for (int x = 0; x < size; x++)
        {
        SecureRandom random = new SecureRandom();
        words.add(new BigInteger(130, random).toString(11));
        }
        
        startTime = System.nanoTime();
          while (System.nanoTime() - startTime < 1000000000) {}
        long timesToLoop = 100;
        startTime = System.nanoTime();
        
        for (long i = 0; i < timesToLoop; i++)
        {
        	tableGood.clear();
        	for(String s : words)
        		{
        		tableGood.add(s);
        		
        		}
        	
        }
        midpointTime = System.nanoTime();
        for (long i = 0; i < timesToLoop; i++) { }
        stopTime = System.nanoTime();
        double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ timesToLoop;
        //double totalTime = (midpointTime - startTime) - (stopTime - midpointTime);
        System.out.println(size + "	" +averageTime + "	" + tableGood.collisions);
        tableGood.collisions = 0;
        //System.out.println("This method takes exactly " + totalTime + " nanoSeconds");
        }
        }

    
    private static ArrayList<String> readWordsFromFile(String filename)
	{
		ArrayList<String> retVal = new ArrayList<String>();
		try 
		{
			BufferedReader input = new BufferedReader(new FileReader(filename));

			while(input.ready())
			{
				retVal.add(input.readLine());
			}
			input.close();
		} 
		catch (FileNotFoundException e) 
		{	
			e.printStackTrace();
		} catch (IOException e) 
		{
			e.printStackTrace();
		}
		return retVal;
	}
    public static Integer randomInt()
    {
        return new Integer(rand.nextInt());
    }
    public final class SessionIdentifierGenerator
    {

      private SecureRandom random = new SecureRandom();

      public String nextSessionId()
      {
        return new BigInteger(130, random).toString(32);
      }

    }
}