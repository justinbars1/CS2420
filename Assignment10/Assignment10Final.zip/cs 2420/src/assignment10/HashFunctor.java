package assignment10;

/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public interface HashFunctor {

  public int hash(String item);

}