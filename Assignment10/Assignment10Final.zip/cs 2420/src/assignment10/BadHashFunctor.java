package assignment10;
/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public class BadHashFunctor implements HashFunctor{

	
	public int hash(String item) {
		
		return 1;
	}

}
