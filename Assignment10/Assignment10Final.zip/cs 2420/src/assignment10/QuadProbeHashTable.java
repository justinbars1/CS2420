package assignment10;

import java.util.Collection;

/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */
public class QuadProbeHashTable implements Set<String>
{
	int arraySize, itemsInArray;
	double loadFactor;
	public String[] hashTable;
	private HashFunctor convert;
	int collisions = 0;
	
	
	public QuadProbeHashTable(int capacity, HashFunctor functor)
	{
		hashTable = new String[primeNumber.nextPrime(capacity)];
		convert = functor;
		itemsInArray = 0;
		arraySize = hashTable.length;
		loadFactor = 0;
	}
	public boolean add(String item) {
		
		if(item == null)
			return true;
		if (hashTable[getIndex(item, hashTable)] == null)
			{
			hashTable[getIndex(item, hashTable)] = item;
			itemsInArray ++;
			}
		
		loadFactor = ((double)(itemsInArray))/((double)(arraySize));
		
		if(loadFactor >= 0.5)
		{
			rehasher();
		}
		return true;
	}

	
	public boolean addAll(Collection<? extends String> items) {
		
		for(String s: items)
			add(s);
		return true;
	}

	
	public void clear() {
		
		hashTable = new String[arraySize];
		itemsInArray = 0;
		loadFactor = 0;
		collisions = 0;
	}

	
	public boolean contains(String item) {
		if(item == null)
			return true;
		int expectedIndex = getIndex(item, hashTable);
		if (hashTable[expectedIndex] == null && item != null)
			return false;
		return hashTable[expectedIndex].compareTo(item) == 0;
	}

	
	public boolean containsAll(Collection<? extends String> items) {
		boolean containsAll = true;
		for (String s: items)
			if (!contains(s))
				containsAll = false;
		return containsAll;
	}

	
	public boolean isEmpty() {
		
		return itemsInArray == 0;
	}

	
	public int size() {
		
		return itemsInArray;
	}
	private void rehasher(){
		String[] temp = new String[primeNumber.nextPrime(arraySize*2)];
		arraySize = temp.length;
		for(String s : hashTable)
		{
			if(s == null)
				continue;
			//int hash = convert.hash(s);
			int index = getIndex(s, temp);
			if (temp[index]!= null)
				System.out.println(temp[index]);
			temp[index] = s;
			
			
			
		}
		loadFactor = ((double)(itemsInArray))/((double)(arraySize));
		hashTable = temp;
	}
	private int getIndex(String item, String[] table){
		if(item == null)
			return 0;
		int hash = convert.hash(item);
		int index = (hash % arraySize);
		while(index >= arraySize)
		{
		 index = index-arraySize;
		}
		if (index != 0)
			index--;
		
		
		
		if ((table[index] != null) && (table[index].equals(item)))
			return index;
		int base2 = 1;
		int base1 = 1;
		while(table[index] != null)
				{
				collisions++;
				
				base1 = base1 +1;//this needs to change to be 1^2 2^2 3^2 etc.
				
				base2 = base1 * base1;
				index = index+base2;
				while(index >= arraySize)
					{
					 index = index-arraySize;
					}
				
				if (table[index] != null&&table[index].equals(item))
					return index;
				
				}	
		
		return index;
	}
 
}
