package assignment12;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;

public class CompressionDemo {

  public static void compressFile(String infile, String outfile) {
    HuffmanTree t = new HuffmanTree();

    t.compressFile(new File(infile), new File(outfile));
    
    t.huffmanToDot("huffman_tree3.dot");
    int[] temp = t.getCode('d');
//    for (int x: temp)
//    	System.out.println(x);
    
  }
  
  public static void decompressFile(String infile, String outfile) {
    HuffmanTree t = new HuffmanTree();

    t.decompressFile(new File(infile), new File(outfile));
  }
  
  public static void main(String[] args) {
   compressFile("a.txt", "compressedA.txt");
    decompressFile("compressedA.txt", "decompressedA.txt");
    compressFile("original.txt", "compressed.txt");
    decompressFile("compressed.txt", "decompressed.txt");
    compressFile("book.txt", "compressedBook.txt");
    decompressFile("compressedBook.txt", "decompressedBook.txt");
    for(int i = 5000; i < 50000; i+=1000){
    	myFile(i, 0);
    compressFile(("out"+i+".txt"),("compressed"+i+".txt"));
    decompressFile(("compressed"+i+".txt"),("decompress"+i+".txt"));
    }
	int k = 0;
    for(int o = 1000; o <= 10000; o+=1000 ){
    	
    	myFile(o, k);
    compressFile(("out"+o+".txt"),("Ucompressed"+o+".txt"));
    decompressFile(("Ucompressed"+o+".txt"),("Udecompress"+o+".txt"));
    System.out.println("uniqueCharacters	"+k);
    //k = k+1;
    }
  }
  public static void myFile(int numberOfWords, int uniqueCharacters ){
	  try{
		  // Create file 
		  FileWriter fstream = new FileWriter("out"+numberOfWords+".txt");
		  BufferedWriter out = new BufferedWriter(fstream);
		  
	  String unique = "&";
	  int wordLength= 5;
	  char[] chTemp = new char[0];
	  int count = 97; //97 122 a-z
	  for(int i = 0; i< numberOfWords; i++){

		  if(i%2 == 0){
			  wordLength = wordLength + 1;
			  chTemp = new char[wordLength];
			  for(int z = 0; z < wordLength; z++){
				  if(count > 122)
					  count = 97;
				  chTemp[z] = (char)count;
				  count++;
			  }
		  }
			  else{
				  wordLength = wordLength - 1;
				  chTemp = new char[wordLength];
				  for(int y = 0; y < wordLength; y++){
					  if(count > 122)
						  count = 97;
					  chTemp[y] = (char)count;
					  count++;
				  }
			  
		  }
		  if(i <= uniqueCharacters )
			  out.write(unique);
		  wordLength= 5;
		  out.write(chTemp);
		  out.write(" ");
		  
	  }
	  //Close the output stream
	  out.close();
	  }catch (Exception e){//Catch exception if any
	  System.err.println("Error: " + e.getMessage());
	  }
  }

}
