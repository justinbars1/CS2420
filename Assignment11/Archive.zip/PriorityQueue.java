package assignment11;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.NoSuchElementException;

/**
 * Represents a priority queue of generically-typed items. 
 * The queue is implemented as a min heap. 
 * The min heap is implemented implicitly as an array.
 * 
 * @author Daniel Kopta
 * Modified by Justin Barsketis and Justin Larsen
 */
public class PriorityQueue<AnyType> {

	private int currentSize;

	private AnyType[] array;

	private Comparator<? super AnyType> cmp;

	/**
	 * Constructs an empty priority queue. Orders elements according
	 * to their natural ordering (i.e., AnyType is expected to be Comparable)
	 * AnyType is not forced to be Comparable.
	 */
	@SuppressWarnings("unchecked")
	public PriorityQueue() {
		currentSize = 0;
		cmp = null;
		array = (AnyType[]) new Object[10]; // safe to ignore warning
	}

	/**
	 * Construct an empty priority queue with a specified comparator.
	 * Orders elements according to the input Comparator (i.e., AnyType need not
	 * be Comparable).
	 */
	@SuppressWarnings("unchecked")
	public PriorityQueue(Comparator<? super AnyType> c) {
		currentSize = 0;
		cmp = c;
		array = (AnyType[]) new Object[10]; // safe to ignore warning
	}

	/**
	 * @return the number of items in this priority queue.
	 */
	public int size() {
		return currentSize;
	}

	/**
	 * Makes this priority queue empty.
	 */
	public void clear() {
		currentSize = 0;
		array = (AnyType[]) new Object[10];
	}

	/**
	 * @return the minimum item in this priority queue.
	 * @throws NoSuchElementException if this priority queue is empty.
	 * 
	 * (Runs in constant time.)
	 */
	public AnyType findMin() throws NoSuchElementException {
		//if empty throw exception
		if (currentSize == 0)
			throw new NoSuchElementException();
		//otherwise return the root.
		return array[0];
	}


	/**
	 * Removes and returns the minimum item in this priority queue.
	 * 
	 * @throws NoSuchElementException if this priority queue is empty.
	 * 
	 * (Runs in logarithmic time.)
	 */
	public AnyType deleteMin() throws NoSuchElementException {
		//If empty, throw exception on delete event attempt
		if (currentSize == 0)
			throw new NoSuchElementException();
		//Store root as a temp to return after percolating
		AnyType temp = array[0];
		//Move last item in tree to root
		array[0] = array[currentSize-1];
		array[currentSize-1] = null;
		//Reduce size
		currentSize--;
		//Move root value down to it's correct position
		percolateDown(0);
		//Return removed value.
		return temp;
	}
	/**
	 * Helper method to recursively swap our evaluated value down the tree until it
	 * 	reaches the correct position
	 * 
	 * @param i - the index value of the node being evaluated.
	 */
	private void percolateDown(int i)
	{
		//BASE CASE: if we've reached the end of the tree, exit
		if (i == currentSize-1)
			return;
		//Store values of the node we're evaluating and it's children
		AnyType temp = array[i];
		AnyType left;
		AnyType right;
		//Check size in case we're on the lowest level of the tree
		//to avoid index out of bounds.
		if (2* i+1 > currentSize)
			left = null;
		else
			left = array[2* i+1];
		if (2* i+1 > currentSize)
			right = null;
		else
			right = array[2* i+2];

		//BASE CASE: if the children are both null, no swaps, exit
		if (right == null && left == null)
			return;
		//BASE CASE:  If the children are not null but are both larger than value at i, exit
		if ((right != null && left != null))
		{
			if (compare(temp, left) <= 0 && compare(temp, right) <= 0)
				return;
		}
		else
		{
			//BASE CASE: If the left child is null and the right is larger than i, exit
			if (left == null && compare(temp, right) <= 0)
				return;
			//BASE CASE: If the right child is null and the left is larger than i, exit
			else if (right == null && compare(temp, left) <= 0)
				return;
		}
		//If left is null and right child is smaller than i, swap and recurse
		if (left == null && compare(temp, right) > 0)
		{
			array[i] = right;
			array[2*i+2] = temp;
			percolateDown(2 * i+2);
			return;
		}
		//If right is null and left child is smaller than i, swap and recurse
		else if (right == null && compare(temp, left) > 0)
		{
			array[i] = left;
			array[2*i+1] = temp;
			percolateDown(2 * i+1);
			return;
		}

		//If right child is larger than left child, swap with i and recurse
		if (compare(array[2* i+2], array[2* i+1]) < 0)
		{
			array[i] = array[2* i + 2];
			array[2*i + 2] = temp;
			percolateDown(2 * i+2);
		}
		//If left child is larger than right child, swap with i and recurse
		else {
			array[i] = array[2* i + 1];
			array[2*i + 1] = temp;
			percolateDown(2 * i + 1);
		}
	}
	
	/**
	 * Helper method to recursively swap our evaluated value up the tree until it
	 * 	reaches the correct position
	 * 
	 * @param i - the index value of the node being evaluated.
	 */
	private void percolateUp(int i)
	{
		//Store evaluated node as a temp variable
		AnyType temp = array[i];
		//BASE CASE: if the evaluated node is larger than the parent, exit
		if (compare(temp, array[(i-1)/2]) >= 0)
			return;
		//Swap evaluated node wth parent, recurse
		else 
		{
			array[i] = array[(i-1)/2];
			array[(i-1)/2] = temp;
			percolateUp((i-1)/2);
		}

	}


	/**
	 * Adds an item to this priority queue.
	 * 
	 * (Runs in logarithmic time.) Can sometimes terminate early.
	 * 
	 * @param x -- the item to be inserted
	 */
	public void add(AnyType x) {
		//If no item is passed to add, add nothing
		if ( x == null)
			return;
		//Grow if needed.
		if (array[array.length-2] != null )
			grow();
		//Add x to the last spot in the tree maintaining completeness
		array[currentSize] = x;
		//Recursively swap up the tree to the correct position
		percolateUp(currentSize);
		//Increment size
		currentSize++;
	}

	/**
	 * Helper method to grow the array when needed
	 */
	@SuppressWarnings("unchecked")
	private void grow()
	{
		//Generate new array that is double the size of current.
		AnyType[] temp = (AnyType[]) new Object[array.length * 2];
		for (int i = 0; i < currentSize; i++)
			temp[i] = array[i];
		//Swap out pointers, GC will destroy old array.
		array = temp;
	}
	
	
	/**
	 * Generates a DOT file for visualizing the binary heap.
	 */
	public void generateDotFile(String filename) {
		try {
			PrintWriter out = new PrintWriter(filename);
			out.println("digraph Heap {\n\tnode [shape=record]\n");

			for(int i = 0; i < currentSize; i++) {
				out.println("\tnode" + i + " [label = \"<f0> |<f1> " + array[i] + "|<f2> \"]");
				if(((i*2) + 1) < currentSize)
					out.println("\tnode" + i + ":f0 -> node" + ((i*2) + 1) + ":f1");
				if(((i*2) + 2) < currentSize)
					out.println("\tnode" + i + ":f2 -> node" + ((i*2) + 2) + ":f1");
			}

			out.println("}");
			out.close();
		} catch (IOException e) {
			System.out.println(e);
		}
	}

	/**
	 * Internal method for comparing lhs and rhs using Comparator if provided by the
	 * user at construction time, or Comparable, if no Comparator was provided.
	 */
	private int compare(AnyType lhs, AnyType rhs) {
		if (cmp == null)
			return ((Comparable<? super AnyType>) lhs).compareTo(rhs); // safe to ignore warning
		// We won't test your code on non-Comparable types if we didn't supply a Comparator

		return cmp.compare(lhs, rhs);
	}



	//LEAVE IN for grading purposes
	public Object[] toArray() { 
		Object[] ret = new Object[currentSize];
		for(int i = 0; i < currentSize; i++)
			ret[i] = array[i];
		return ret;
	}
}
