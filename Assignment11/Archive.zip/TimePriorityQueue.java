package assignment11;

import java.util.Random;

public class TimePriorityQueue {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		Random rand = new Random();
		rand.setSeed(13); //simple prime seed for tracing if needed.
		double avgSingleAdd, avgTotalAdd, findMin, avgSingleDelMin, avgTotalDelMin, timeToWait;
		int nMax, timesToLoop;
		timeToWait = 1000000000;
		timesToLoop = 10;
		nMax = 1000000;
		System.out.println("N,AvgSingleAdd,avgTotalAdd,findMin,avgSingleDelMin,avgTotalDelMin");
		
		for (int i = 10000; i < nMax; i+=10000)
		{
			double totalAdd, totalDel; 
			avgSingleAdd = avgTotalAdd = findMin = avgSingleDelMin = avgTotalDelMin = totalAdd = totalDel = 0;
			PriorityQueue test = new PriorityQueue();
			double startTime, stopTime;
			startTime = stopTime = 0;
			//test Adds
			for(int j = 1; j <= timesToLoop; j++)
			{
				test.clear();
				startTime = stopTime = 0;
				startTime = System.nanoTime();
				while(System.nanoTime() - startTime < timeToWait);//even out thread
				//add i items to the structure
				for(int k = 0; k < i; k++)
				{
					test.add(rand.nextInt(i*2));
				}
				stopTime = System.nanoTime();
				totalAdd += (stopTime - startTime - timeToWait);
				startTime = stopTime = 0;
				
				//test deleteMin
				startTime = System.nanoTime();
				while(System.nanoTime() - startTime < timeToWait);//even out thread
				for(int k = i; k > 0; k--)
				{
					test.deleteMin();
				}
				stopTime = System.nanoTime();
				totalDel += (stopTime - startTime - timeToWait);
				startTime = stopTime = 0;
				
			}
			
			//test findMin, bump up times to loop.
			test.clear();
			for(int k = 0; k < i; k++)
			{
				test.add(rand.nextInt(i*2));
			}
			startTime = System.nanoTime();
			while(System.nanoTime() - startTime < timeToWait);//even out thread
			for (int k = 0; k < timesToLoop * 100000; k++)
			{
				test.findMin();
			}
			stopTime = System.nanoTime();
			
			findMin = (double)(stopTime - startTime - timeToWait)/(double)(timesToLoop * 100000);
			
			avgSingleAdd = (double)totalAdd / (double)i / (double)timesToLoop;
			avgTotalAdd = (double)totalAdd / (double)timesToLoop;
			avgSingleDelMin = (double)totalDel / (double)i / (double)timesToLoop;
			avgTotalDelMin = (double)totalDel / (double)timesToLoop;
			
			
			
		
			
			System.out.println(i + "," +
					+ avgSingleAdd + "," + 
					avgTotalAdd + "," + findMin + "," + 
					avgSingleDelMin + "," + avgTotalDelMin);
		}
	}

}
