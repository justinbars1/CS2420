package assignment11;

import java.util.NoSuchElementException;
import java.util.Random;

import junit.framework.TestCase;

public class TestPriorityQueue extends TestCase {
	Random rand = new Random();
	PriorityQueue small = new PriorityQueue();
	PriorityQueue unbalanced = new PriorityQueue();
	PriorityQueue medium = new PriorityQueue();
	PriorityQueue empty = new PriorityQueue();
	PriorityQueue ordered = new PriorityQueue();
	PriorityQueue duplicates = new PriorityQueue();
	

	protected void setUp() throws Exception {
		super.setUp();
		rand.setSeed(7);
		//Add values for testing
		small.add(0);small.add(1);small.add(2);
		unbalanced.add(0);unbalanced.add(32);unbalanced.add(3);unbalanced.add(3);unbalanced.add(64);
		//add random values to medium
		for (int i = 0; i < 40; i++)
		{
			int temp = rand.nextInt(100);
			medium.add(temp);
		}
		for (int i = 0; i < 40; i++)
		{
			int temp = 42;
			duplicates.add(temp);
		}
		medium.add(-1);
		//add sequential values to ordered
		for (int i = 1; i <= 100; i++)
			ordered.add(i);

	}

	public void testFindMin() {
		//Operation Tests
		assertEquals(-1, medium.findMin());
		assertEquals(0, small.findMin());
		assertEquals(0, unbalanced.findMin());
		assertEquals(42, duplicates.findMin());
		//Test error throw on empty
		Throwable error = null;
		try{
			empty.findMin();
		}catch(Throwable e)
		{
			error = e;
		}
		assertNotNull(error);
		assertSame(NoSuchElementException.class, error.getClass());	
	}

	public void testDeleteMin() 
	{
		//Pre-Conditions
		assertEquals(41, medium.size());
		assertEquals(3, small.size());
		assertEquals(5, unbalanced.size());
		medium.generateDotFile("MediumQueueBeforeDelete.dot");
		unbalanced.generateDotFile("unbalancedQueueBefore.dot");
		//Operation
		assertEquals(-1, medium.deleteMin());
		assertEquals(0, small.deleteMin());
		assertEquals(0, unbalanced.deleteMin());
		unbalanced.generateDotFile("unbalancedQueueAfter.dot");
		//Post-Conditions
		assertEquals(40, medium.size());
		assertEquals(2, small.size());
		assertEquals(4, unbalanced.size());
		medium.generateDotFile("MediumQueueAfter.dot");
		//Loop to empty on medium
		for (int i = 40; i > 0; i--)
		{
			medium.deleteMin();
			assertEquals(i-1, medium.size());
		}
		//Loop to empty on duplicates
		for (int i = 40; i > 0; i--)
		{
			assertEquals(42, duplicates.deleteMin());
			assertEquals(i-1, duplicates.size());
		}
		//Loop to empty on ordered, assert min value each time
		for (int i = 1; i <= 100; i++)
		{
			assertEquals(100+1-i, ordered.size()); //pre
			assertEquals(i, ordered.deleteMin()); //operation
			assertEquals(100-i, ordered.size()); //post
		}
		//Test empty operations
		//empty
		Throwable error = null;
		try{
			empty.deleteMin();
		}catch(Throwable e)
		{
			error = e;
		}
		assertNotNull(error);
		assertSame(NoSuchElementException.class, error.getClass());	
		//medium cleared, should throw an error
		error = null;
		try{
			medium.deleteMin();
		}catch(Throwable e)
		{
			error = e;
		}
		assertNotNull(error);
		assertSame(NoSuchElementException.class, error.getClass());	
		//ordered cleared, should throw an error
		error = null;
		try{
			ordered.deleteMin();
		}catch(Throwable e)
		{
			error = e;
		}
		assertNotNull(error);
		assertSame(NoSuchElementException.class, error.getClass());	


	}

	public void testAdd() {
		assertEquals(-1, medium.findMin());
		medium.add(-512);
		assertEquals(-512, medium.findMin());
		medium.clear();
		assertEquals(0, medium.size());
		rand.setSeed(7);
		//force grow, ensure that min shifts each time.
		for (int i = 1; i < 10000; i++)
		{
			medium.add(i*-1);
			assertEquals(i*-1, medium.findMin());
			assertEquals(i, medium.size());
		}
		//test that null doesn't insert
		assertEquals(40, duplicates.size());
		assertEquals(42, duplicates.findMin());
		duplicates.add(null);
		assertEquals(42, duplicates.findMin());
		assertEquals(40, duplicates.size());
		//test inserting a low value on an array full of duplicates
		duplicates.add(-58);
		assertEquals(-58, duplicates.findMin());
		assertEquals(41, duplicates.size());
		
		
	}

}
