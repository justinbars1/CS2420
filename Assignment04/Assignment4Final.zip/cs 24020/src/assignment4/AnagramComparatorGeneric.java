package assignment4;

import java.util.Comparator;

public class AnagramComparatorGeneric implements Comparator<String> {



@Override
public int compare(String o1, String o2) {
	
	return (AnagramUtil.sort(o1)).compareTo(AnagramUtil.sort(o2));
}
}

