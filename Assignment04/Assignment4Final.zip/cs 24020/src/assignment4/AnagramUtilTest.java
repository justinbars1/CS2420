package assignment4;

import junit.framework.TestCase;

import org.junit.Test;

public class AnagramUtilTest<T> extends TestCase{
	String unsorted, empty, sorted, singles, doubles, doublesSorted;
	String[] unsortedList = new String[10];
	String[] unsortedList2 = new String[10];
	
	String[] sortedList = new String[10];
	String[] smallList = new String[1];
	String[] smallList2 = new String[1];
	String[] smallList3 = new String[1];
	String[] emptyList;
	String[] largeAnagramList = new String[13];
	String [] expectedList = new String[3];
	String[] doubleList = new String[2];
	String[] doubleList2 = new String[2];
	String[] doubleList3 = new String[2];
	String[] caps = new String[3];
	String[] caps2 = new String[3];
	String[] caps3 = new String[3];
	String[] capsExpected = new String[3];
	String[] doubleExpected = new String[2];
	AnagramComparatorGeneric cmp = new AnagramComparatorGeneric();
	StringComparator cmp1 = new StringComparator();
	ArrayComparator cmp2 = new ArrayComparator();
	public void setUp() throws Exception 
	{
		
		
		emptyList = new String[0];
		
		unsorted = "apple";
		singles = "z";
		doubles = "za";
		doublesSorted = "az";
		doubleList[0] = "bca"; doubleList[1] = "abc";
		doubleList2[0] = "bca"; doubleList2[1] = "abc";
		doubleList3[0] = "bca"; doubleList3[1] = "abc";
		caps[0] = "Abc"; caps[1] = "Def"; caps[2] = "Ghi";
		caps2[0] = "Abc"; caps2[1] = "Def"; caps2[2] = "Ghi";
		caps3[0] = "Abc"; caps3[1] = "Def"; caps3[2] = "Ghi";
		capsExpected[0] = "Abc"; capsExpected[1] = "Def"; capsExpected[2] = "Ghi";
		doubleExpected[0] = "abc"; doubleExpected[1] = "bca";
		sorted = "aelpp";
		unsortedList[0] = "zoo";unsortedList[1] = "animal";unsortedList[2] = "banana";unsortedList[3] = "cucumber";unsortedList[4] = "rectangle";unsortedList[5] = "final";
		
		unsortedList2[0] = "zoo";unsortedList2[1] = "animal";unsortedList2[2] = "banana";unsortedList2[3] = "cucumber";unsortedList2[4] = "rectangle";unsortedList2[5] = "final";
		
		
		sortedList[0] = "animal";sortedList[1] = "banana";sortedList[2] = "cucumber";sortedList[3] = "final";sortedList[4] = "rectangle";sortedList[5] = "zoo";
		smallList[0] = "yep";
		smallList2[0] = "yep";
		smallList3[0] = "yep";
		
	largeAnagramList[0]= "dab";largeAnagramList[1]= "bad";largeAnagramList[2]= "gre";largeAnagramList[3]= "reg";largeAnagramList[4]= "qsde";
			largeAnagramList[5]= "qwty";largeAnagramList[6]= "green";largeAnagramList[7]= "red";largeAnagramList[8]= "blue";largeAnagramList[9]= "purple";
			largeAnagramList[10]= "der";largeAnagramList[11]= "nereg";largeAnagramList[12]= "adb";
			expectedList = new String[largeAnagramList.length]	;	
			expectedList[0] ="dab";expectedList[1]= "bad";expectedList[2]= "adb";
		//isSorted Method, checks the next item in the list to make sure its in order
	}

	
	@Test
	public void testAreAnagramsNull()
	{
			assertTrue(AnagramUtil.areAnagrams(null,null));
	}
	public void testAreAnagrams()
	{
			assertTrue(AnagramUtil.areAnagrams(unsorted,sorted));
	}
	public void testAreAnagramsSingle()
	{
			assertTrue(AnagramUtil.areAnagrams("a","a"));
	}
	public void testAreAnagramsSingleFalse()
	{
			assertFalse(AnagramUtil.areAnagrams("a","b"));
	}
	public void testAreAnagramsDouble()
	{
			assertTrue(AnagramUtil.areAnagrams("ab","ba"));
	}
	public void testAreAnagramsFalse()
	{
			assertFalse(AnagramUtil.areAnagrams("acdfe","asderas"));
	}
	public void testSortnull()
	{
			assertEquals(null, AnagramUtil.sort(null));
	}
	public void testSort1()
	{
			assertEquals(sorted, AnagramUtil.sort(unsorted));
	}
	public void testSort2()
	{
		assertEquals(doublesSorted, AnagramUtil.sort(doubles));
	}
	public void testSort()
	{
		assertEquals(singles, AnagramUtil.sort(singles));
	}
	public void testSortEmpty()
	{
		assertEquals(empty, AnagramUtil.sort(empty));
	}
	public void testInsertionSortNull()
	{
		AnagramUtil.insertionSort(null, cmp1);
		assertTrue(cmp2.compare(null, null) == 0);
	}
	public void testInsertionSortEmpty()
	{
		AnagramUtil.insertionSort(emptyList, cmp1);
		assertTrue(emptyList.length == 0);
	}
	public void testInsertionSortDouble()
	{
		AnagramUtil.insertionSort(doubleList, cmp1);
		assertTrue(cmp2.compare(doubleList, doubleExpected) == 0);
	}
	public void testInsertionSortSingle()
	{
		AnagramUtil.insertionSort(smallList, cmp1);
		assertTrue(cmp2.compare(smallList, smallList2) == 0);
	}
	public void testInsertionSort1()
	{
			AnagramUtil.insertionSort(unsortedList, cmp1);
			assertTrue(cmp2.compare(sortedList, unsortedList) == 0);
	}
	
	
	public void testShellSort1()
	{
			AnagramUtil.shellSort(unsortedList2, cmp1);
			assertTrue(cmp2.compare(sortedList, unsortedList2) == 0);
	}
	public void testShellSortSingle()
	{
		AnagramUtil.shellSort(smallList3, cmp1);
		assertTrue(cmp2.compare(smallList, smallList3) == 0);
	}
	public void testShellSortDouble()
	{
		AnagramUtil.shellSort(doubleList3, cmp1);
		assertTrue(cmp2.compare(doubleList3, doubleExpected) == 0);
	}
	public void testShellSortEmpty()
	{
		AnagramUtil.shellSort(emptyList, cmp1);
		assertTrue(cmp2.compare(emptyList, emptyList) == 0);
	}
	public void testShellSortNull()
	{
		AnagramUtil.shellSort(null, cmp1);
		assertTrue(cmp2.compare(null, null) == 0);
	}
	
	
	public void testgetLargestAnagramGroup()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(largeAnagramList), expectedList));
	}
	public void testgetLargestAnagramGroupNull()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(null), emptyList));
	}
	public void testgetLargestAnagramGroupEmpty()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(emptyList), emptyList));
	}
	public void testgetLargestAnagramGroupSingle()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(smallList3), smallList));
	}
	public void testgetLargestAnagramGroupDouble()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(largeAnagramList), expectedList));
	}
	public void testInsertionSortcaps()
	{
			AnagramUtil.insertionSort(caps, cmp1);
			assertTrue(cmp2.compare(capsExpected, caps) == 0);
	}
	
	public void testShellSortcaps()
	{
			AnagramUtil.shellSort(caps2, cmp1);
			assertTrue(cmp2.compare(capsExpected, caps2) == 0);
	}
	public void testgetLargestAnagramGroupCaps()
	{
			assertEquals(0, cmp2.compare(AnagramUtil.getLargestAnagramGroup(caps3), capsExpected));
	}
	
//	public void testisSorted()
//	{
//		assertTrue(isSorted(sortedList));
//		
//	}
//	public  boolean isSorted (String[] list)
//	{
//		boolean isSorted = true;
//		for (int x = 1; x < list.length - 1; x++)
//		{
//			String current = list[x];
//			String last = list[x-1];
//			if (cmp.compare(last, current) < 0)
//				isSorted = false;
//		}
//		return isSorted;
//	}

}
