package assignment4;

import java.util.Comparator;

public class StringComparator implements Comparator<String> {

	/**
	 * 
	 * This comparator compares string items
	 *
	 */

@Override
public int compare(String o1, String o2) {
	if (o1 == null && o2 == null)
		return 0;
	else if (o1 == null || o2 == null)//null checks
		return 1;
	o1.toLowerCase();
	o2.toLowerCase();
	return o1.compareTo(o2);
}
}