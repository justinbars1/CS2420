package assignment4;

import java.util.Comparator;
/**
 * 
 * This comparator compares string anagrams based off their sorted value
 *
 */
public class AnagramComparator {

	public static Comparator<String> AnagramComparator = new Comparator<String>()
			{
		public int compare(String o1, String o2) 
		
			{
			
			return (AnagramUtil.sort(o1)).compareTo(AnagramUtil.sort(o2));
			}
		
		
		};
}
