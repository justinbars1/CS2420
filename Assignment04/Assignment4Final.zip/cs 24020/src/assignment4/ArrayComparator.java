package assignment4;

import java.util.Comparator;
/**
 * 
 * This comparator compares items in a string array based of there regular lexigraphical values
 *
 */
public class ArrayComparator implements Comparator<String[]> {



@Override


public int compare(String[] o1, String[] o2) {
	boolean isEqual = true;
	if(o1 == null && o2 == null)
		return 0;
	if(o1 == null && o2 != null)
		return 1;
	else if( o1!= null && o2 == null)
		return 1;
	if (o1.length == 0 && o2.length == 0)//all these checks check to see if one or both arrays contain null or an empty array
		return 0;							//and returns the correct values 
	else if ((o1.length == 0 && o2.length != 0) || (o2.length == 0 && o1.length != 0))
		return 1;
	AnagramUtil.toLowerCase(o1);
	AnagramUtil.toLowerCase(o2);

	for (int x = 0; x < o1.length && o1[x] != null && o2[x] != null; x++)
	{
		if (!(o1[x].equals(o2[x])))
		{
			isEqual = false;
		}
	}
	if (isEqual)
		return 0;
	else
		return 1;
}
}