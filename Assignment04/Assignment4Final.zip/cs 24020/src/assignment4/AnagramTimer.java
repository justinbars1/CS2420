package assignment4;


import java.util.Random;

public class AnagramTimer {
	private static Random rand;
	@SuppressWarnings("unused")
	public static void main(String[] args)
	{
		String[] junk = new String[0];
		AnagramTester.main(junk);
		for (int y = 0; y <= 20;y++)
	{
		int wordSize = 100*y;
		int arraySize = 100*y;
		String[] testArray = new String[arraySize];
		for (int x = 0; x < arraySize ; x++)
			testArray[x] = AnagramTester.randomString(10);
		rand = new Random();
		rand.setSeed(System.currentTimeMillis());
		AnagramComparatorGeneric cmp = new AnagramComparatorGeneric();
		StringComparator cmp1 = new StringComparator();
		ArrayComparator cmp2 = new ArrayComparator();
		String s = AnagramTester.randomString(wordSize);
		String a = AnagramTester.randomString(wordSize);
	//	String[] inputAnagramFile = AnagramTester.readFile("/Users/Authenticated User/Documents/workspace/cs 2420/src/assignment4/sample_word_list");

		long startTime, midpointTime, stopTime;
	    startTime = System.nanoTime();
  	    while (System.nanoTime() - startTime < 1000000000) {}
	    long timesToLoop = 1000;
	    startTime = System.nanoTime();
	    
	    for (long i = 0; i < timesToLoop; i++)
	    {
	   // 	AnagramUtil.areAnagrams(s, a);
//	    	AnagramUtil.findMostAnagrams(inputAnagramFile);// this will run the test on the sample_word_list file to find the most anagrams in the file.
//	    		 findMostAnagrams timesToLoop = 10000.
	    	//AnagramUtil.insertionSort(testArray, cmp);// this will run the insertionsort on the sample_word_list.
	    		//insertionSort timesToLoop = 10000.
	    	AnagramUtil.getLargestAnagramGroup(testArray);// this will run the getLargestAnagramGroup which returns the list of original words in the file that are anagrams.
	    		// getLargestAnagramGroup timesToLoop = 1000.
	    	//AnagramUtil.shellSort(testArray, cmp);// this will run the shellSort on the sample_word_list
	    		// shellSort timeToLoop = 10000.
	    }
	    midpointTime = System.nanoTime();
	    for (long i = 0; i < timesToLoop; i++) { }
	    stopTime = System.nanoTime();
	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ timesToLoop;
	    double totalTime = (midpointTime - startTime) - (stopTime - midpointTime);
	    System.out.println(y + "	" + averageTime);
	    //System.out.println("This method takes exactly " + totalTime + " nanoSeconds");
	}
}
}
