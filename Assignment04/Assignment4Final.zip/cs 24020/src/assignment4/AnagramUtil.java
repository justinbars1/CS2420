package assignment4;

import java.util.Comparator;
/**
 * 
 * @author Justin Barsketis and Aaron Smith
 *
 * This method preforms a variety of task on anagrams
 */
public class AnagramUtil implements Comparator<String>{
	

//This method returns the sorted version of the input string. The sorting must be accomplished using an insertion sort.
    public static String sort(String input){
    	if (input == null)
    		return null;
    	char[] s = input.toLowerCase().toCharArray();
    	String returnString;
    	
    	for (int i = 1; i < s.length; i++)
    	{
    		
    		int j = i; //set j to the starting position
    		char temp = s[i];
    		while (j > 0 && s[j - 1] > temp)// while a switch is needed, loop through to find where it should go
    		{
    			s[j] = s[j-1]; //move back the item
    			j--;//decrement j so that it looks switches with the value before it
    		}
    		s[j] = temp;//switch the old value
    	}
    	returnString = new String(s);
    	
    	return returnString; 	
    }


    //This generic method sorts the input array using an insertion sort and the input Comparator object.
    public static <T> void insertionSort(T[ ] list, Comparator<? super T > cmp)
    {

    	if ( list == null || cmp == null)//null check
    		return;
    	if (list instanceof String[])	//if it is a list, convert all strings to lower case
    		toLowerCase((String[])list);
    		
    	
    	for (int i = 1; i < list.length && list[i] != null; i++)
    	{
    		int j = i; //set second iterator to whatever iteration i is in
    		T temp = list[i]; //set a temp variable to hold value
    		while (j > 0 && cmp.compare(list[j - 1], temp) > 0)
    		{
    			list[j] = list[j-1];//keep looking back until the value is near the right place
    			j--;
    		}
    		list[j] = temp;
    	}
    	
    }

    //This generic method sorts the input array using a Shell sort and the input Comparator object.
    public static <T> void shellSort(T[] list, Comparator<? super T> cmp)
    {
    	if ( list == null || cmp == null)//null check
    		return;
    	if (list instanceof String[])	//if it is a list, convert all strings to lower case
    		toLowerCase((String[])list);
    	T temp;
    	int outerLimit, innerLimit;
    	int gap = 1; //set intial gap to one
    	while (gap <= list.length /3) // if gap divided three is greater then 1, then set gap to right value
    	{
    		gap = gap * 3 + 1; //set the gap based on the value divided by three + 1
    	}
    	while (gap > 0) //continue to decrease the gap until gap = 1
    	{
    		for (outerLimit = gap; outerLimit < list.length && list[outerLimit] !=null; outerLimit++)
    		{
    			temp = list[outerLimit]; //set temp value to hold the outerlimit we are testing
    			innerLimit = outerLimit;//set the innerLimit value now to the outer limit then selection sort it
    			while(innerLimit > gap -1 && cmp.compare(list[innerLimit - gap], temp) >= 0)//if innerlimit by gap is greater then zero and the value is less then
    			{
    				list[innerLimit] = list[innerLimit - gap]; //if the value is found to be less, move it left by value of gap
    				innerLimit = innerLimit - gap; //reset innerLimit
    			}
    			list[innerLimit] = temp;//set value back to temp file
    		}
    			
    			
    		gap = (gap - 1) / 3; //decrease gap size
    	}
    	
    	
    }

         
//This method returns true if the two input strings are anagrams of each other, otherwise returns false.

    public static boolean areAnagrams(String s, String a)
    {  
    	if (s == null && a == null)
    		return true;
    	else if (s == null || a == null)//null checks
    		return false;
    	s = s.toLowerCase();
    	a = a.toLowerCase();
    	boolean areAnagrams = (AnagramUtil.sort(s)).compareTo(AnagramUtil.sort(a)) == 0;//sort and compare to zero
    	return areAnagrams;//return boolean
    }

    //This method returns the largest group of anagrams in the input array of words, in no particular order.
    //It returns an empty array if there are no anagrams in the input array. Use either an insertion sort or a Shell sort to achieve this.
    //The reason for having both sorting algorithms is for the analysis portion of this assignment.
    //In order to properly complete the analysis portion of this assignment, this method must use the algorithm described in section 1 of this assignment (use a sort).
    public static String[] getLargestAnagramGroup(String[] list)
    {
    	
    	String[] anagramList = new String[0];
    	if(list == null)
    		return anagramList;
    	toLowerCase((String[])list);//convert all string to lower case
    	String[] tempList = new String[list.length];//create a new array to hold sorted items
    	AnagramComparatorGeneric cmp = new AnagramComparatorGeneric();
    	if (list.length == 0)
    		return anagramList; //if the input array is empty then return empty array
    	for (int x = 0; x < list.length && list[x] != null; x++)
    	{
    		tempList[x] = list[x];//take items out of anagrams list and add them to temp list with words sorted
    	}
    	insertionSort(tempList, cmp); //sort the tempList with an AnagramComparator or the selection sort
    	//Arrays.sort(tempList);
    	for(int x = 0; x < tempList.length && tempList[x] != null; x++)//sort all the words in the list
    	{
    		tempList[x] = sort(tempList[x]);
    	}
    	String key = findMostAnagrams(tempList);//find out which anagram appears most frequently
    	anagramList = new String[list.length];//set array to the size of the old one so you know it big enough
    	int q = 0;
    	for (int y = 0; y < tempList.length && list[y] != null; y++)//iterate one last time to get original values into the new array
    	{
    		if (sort(list[y]).compareTo(key) == 0)//if they are equal to each other
    		{
    			anagramList[q] = list[y];
    			q++;// add to variable q, position should only change when match is found
    		}
    		}
    		
    	
    	return anagramList;//return the list
    } 
    /**

    @param list, this list is a list of sorted anagrams
    @return mostAnagrams, returns the sorted string value that contains the most instances of it
   
    */
    public static String findMostAnagrams (String[] list)
    {
    	toLowerCase((String[])list);//convert all string to lower case
    	String mostAnagrams = list[0];//set mostAnagrams to the first string in the list
    	
    	int highestCount = 0;//set counts to 0
    	int currentCount = 1;
    	for (int x = 0; x < list.length -1; x++)//set up for loop to iterate through list
    	{
    		if (list[x+1] == null)//if the item after is null, exit out of loop
    			break;
    		
    		if (list[x].compareTo(list[x+1]) == 0)//if the item in the list and the item after it are equal to each other
    		{
    			currentCount++;
    		}
    		else//if they are not equal reset current count value
    		{
    			currentCount = 1;
    		}
    		if (currentCount > highestCount)//if the currentCount is greater then the last highest count
    		{
    			mostAnagrams = list[x];//set the most value to the current item in the list
    			highestCount = currentCount;//set highestCount to currentCount
    		}
    	}
    	
    	return mostAnagrams;
    }
    /**
     * 
     * @return returns an array containing only lower case elements
     * @param list, list containing upper-case characters
     */
    public static void toLowerCase (String[] list)
    {
    	if (list.length == 0 || list == null)
    		return;
    	
    	for (int x = 0; x < list.length && list[x] != null; x++)
    		list[x] = list[x].toLowerCase();
    	
    	
    }
    

	@Override
	public int compare(String o1, String o2) {//this compare method is the implemented comparator class
    	if (o1 == null && o2 == null)//if both items are null then return equals or 0
    		return 0;
    	else if (o1 == null || o2 == null)//if one item is null and the other isnt return not equal or 1
    		return 1;
		o1.toLowerCase();//perform lowercase conversions
		o2.toLowerCase();
		return (AnagramUtil.sort(o1)).compareTo(AnagramUtil.sort(o2));//sort both words, compare and return value
	}
	
	

       
	
	  
}

