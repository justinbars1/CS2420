package assignment3;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;

public class TestArrayCollection {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		ArrayCollection<Integer> test1 = new ArrayCollection<Integer> ();
		
		if(!test1.isEmpty())
			System.err.println("isEmpty Failed");
		test1.add(1);
		test1.add(2);
		test1.add(3);
		test1.add(4);
		test1.add(5);
		test1.remove(4);
		if (test1.contains(65))
			System.err.println("contains Failed");// This should not print 
		if (test1.contains(3))
			System.out.println("test1 contains 3 should print");
		if (test1.contains(52))
			System.out.println("test1 doesnot contain 52, this should not print");
		if (test1.contains(23))
			System.err.println("contains Failed");

		
		
		Object[] toPrint = test1.toArray();
		for (Object s: toPrint)
			System.out.println(s);
		test1.clear();
				if(!test1.isEmpty() || test1.size != 0)
					System.err.println("clear Failed");
				
		ArrayCollection<Integer> test2 = new ArrayCollection<Integer>();
		ArrayCollection<Integer> test3 = new ArrayCollection<Integer> ();
		ArrayCollection<Integer> test4 = new ArrayCollection<Integer> ();
		test1.add(43);
		test2.add(43);
		test1.add(44);
		test2.add(44);
		test1.add(55);
		test2.add(55);
		test3.add(1);
		test3.add(2);
		test3.add(3);
		test3.add(4);
		test4.add(4);
		test4.add(3);
		test4.add(2);
		test4.add(1);
		System.out.println(test3.remove(2)+": this is the boolean for remove");
		IntegerComparator cmp2 = new IntegerComparator();
		ArrayList<Integer> toPrint4 = test4.toSortedList(cmp2);
		for (Integer x: toPrint4)
			System.out.println(x);
		
		if(test2.containsAll(test1))
		{
			System.out.println("containsAll is working!");
		}

		if(test3.containsAll(test1))
		{
			System.err.println("containsAll failed");
		}	
		test3.iterator().next();// this should call 2
		test3.iterator().remove(); // this should remove 2
		System.out.println(test3.iterator().next()+": this is the next call and should be 4");
		test3.add(5);
		System.out.println(test3.iterator().next()+": this is the next call and should be 5");

		ArrayList<Integer> searchArray = new ArrayList<Integer>();
		searchArray.add(1);
		searchArray.add(2);
		searchArray.add(3);
		searchArray.add(4);
		searchArray.add(5);
		IntegerComparator cmp = new IntegerComparator();
		System.out.println(SearchUtil.binarySearch(searchArray, 4, cmp));
		
		ArrayList<Integer> searchEmpty = new ArrayList<Integer>();
		boolean isFoundEmpty = SearchUtil.binarySearch(searchEmpty, 3, cmp);
		System.out.println("Empty is " + isFoundEmpty);
	}
	
}
