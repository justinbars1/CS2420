package assignment3;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * @author Aaron Smith and Justin Barsketis Implements the Collection interface
 *         using an array as storage. The array must grow as needed. All methods
 *         should be implemented as defined by the Java API, unless otherwise
 *         specified in the assignment.
 * 
 *         It is your job to fill in the missing implementations and to comment
 *         this class. Every method should have comments (Javadoc-style
 *         prefered, but not necessary). The comments should at least indicate
 *         what the method does, what the arguments mean, and what the returned
 *         value is. It should specify any special cases that the method
 *         handles. Any code that is not self-explanatory should be commented.
 * 
 * @param <E>
 *            - generic type placeholder
 */
public class ArrayCollection<E> implements Collection<E> {

	E data[]; // Storage for the items in the collection
	int size; // Keep track of how many items we hold
	int position = 0;// jkasdfl;asdkfljasdklfasdfhasdjkfha;sldhf;asdf
	Object object1;// aksjdflkjasdflkjasl;kdjf;lkajsdflkjasdfkljsadf

	// There is no clean way to convert between E and Object, the text book
	// discusses this.
	@SuppressWarnings("unchecked")
	public ArrayCollection() {
		size = 0;
		// We can't instantiate an array of unknwon type E, so we must create an
		// Object array, and typecast
		data = (E[]) new Object[10]; // Start with an initial capacity of 10
	}

	/**
	 * This is a helper function specific to ArrayCollection Doubles the size of
	 * the data storage array, retaining its current contents.
	 */
	@SuppressWarnings("unchecked")
	private void grow() {
		E data2[];
		data2 = (E[]) new Object[size * 2];
		for (int x = 0; x < size; x++)
			data2[x] = data[x];
		data = data2;

	}

	public boolean add(E arg0) {
		if (size == data.length)// if the array is already full then grow array
			grow();
		data[size] = arg0;
		size++;// add contents and increase size

		return true;
	}

	public boolean addAll(Collection<? extends E> arg0) {
		for (E temp : arg0)
			// loop through and add all items
			add(temp);
		return true;
	}

	public void clear() {
		data = (E[]) new Object[10];
		size = 0;// create new array then set data to it, reset size

	}

	public boolean contains(Object arg0) {
		boolean containsData = false;
		for (int x = 0; x < size; x++){
			if(data[x] == null)
				break;
			if (data[x].equals(arg0)) // if the any object within the array equals the data then set boolean to true.
			{						
				containsData = true;
			}
		}
		return containsData;
	}

	public boolean containsAll(Collection<?> arg0) {
		boolean containsAllData = false;
		Object[] array2 = data;		
		Object[] array1 = arg0.toArray();
		int count = arg0.size();
		if (arg0 == null || arg0.size() == 0 || arg0.size()!= data.length)
			containsAllData = false;
		for(int i = 0; i < count; i++)
		{
			if(array1[i].equals(array2[i]))
				containsAllData = true;
			else
				containsAllData = false;
		}
		
		
		return containsAllData;
	}

	public boolean isEmpty() {
		if (size == 0)
			return true;
		return false;
	}

	public Iterator<E> iterator() {
		
		Iterator<E> temp = new ArrayCollectionIterator();
		if(temp.hasNext())
			return temp; //This calls ArrayCollectionIterator's hasNext method and returns the argument
		if(temp.next() != null)
			return temp; //This calls ArrayCollectionIterator's next method and returns the argument
		else
			return temp;
	}

	public boolean remove(Object arg0) {
		boolean isReached = false;
		int count1 = 0;
		int count2 =0;
		E[] removeArray = data;
		if(data == null)
			isReached = false;
		for(E temp:data){
			if(temp == null)
				break;
			if(temp.equals(arg0))
			{
				isReached = true;
				count2++;
				
			}
			removeArray[count1] = data[count2];
			count1++;
			count2++;
		}
		data = removeArray;
		size--;
		return isReached;
	}

	public boolean removeAll(Collection<?> arg0) {
		for (Object temp : arg0)
			remove(temp);
		return true;
	}

	public boolean retainAll(Collection<?> arg0) {
		E[] retainer = (E[]) new Object[size];
		int location = 0;
		boolean contains = false;
		for (Object temp : arg0)

			for (E temp2 : data) {
				if (temp2.equals(temp)) {
					retainer[location] = temp2;
					location++;
					contains = true;
				}
			}

		data = retainer;// if anything was found set data to the new list
		if (contains)// if anything was added to the new list, set size to the
						// new size
			size = location;

		return contains;
	}

	public int size() {

		return size;
	}

	public Object[] toArray() {
		E[] temp = (E[]) new Object[size];

		for (int x = 0; x < size; x++) {

			temp[x] = data[x];

		}
		return temp;
	}

	/*
	 * Don't implement this method (unless you want to). It must be here to
	 * complete the Collection interface. We will not test this method.
	 */
	public <T> T[] toArray(T[] arg0) {
		return null;
	}

	/*
	 * Sorting method specific to ArrayCollection - not part of the Collection
	 * interface Must implement a selection sort (see Assignment 2 for code).
	 */
	public ArrayList<E> toSortedList(Comparator<? super E> cmp) {
		ArrayList<E> sorted = new ArrayList<E>(size +1);
		for (int i = 0; i < size() - 1; i++) {
			int j, minIndex;

			for (j = i + 1; j < size(); j++) {
				if (cmp.compare(data[j], data[i]) < 0)
				{
				Object temp = data[i];

				data[i]= data[j];
				data[j] = (E)temp;
				}
			}
			
				

		}
		for (int x = 0; x < size(); x++)
			sorted.add(x, data[x]);

		return sorted;
	}

	private class ArrayCollectionIterator implements Iterator<E> {
		boolean canRemove;

		
		ArrayCollection<E> E = new ArrayCollection<E>();
			
		public ArrayCollectionIterator() {
			
			canRemove = false;
				
			
		}

		public boolean hasNext() {
			if( data == null)
				canRemove = false;
			if (data[position + 1] != null)
				canRemove = true;
			else
				canRemove = false;
			return canRemove;
		}

		public E next() {

			if (hasNext()) {
				object1 = data[position + 1];
				position++;
				canRemove = true;
				return data[position];
			}
			 else {
				System.err.println("NoSuchElementException");
				return null;
			}

		}
		
		public void remove() {
			if (canRemove) {
				for (int x = 0; x <size; x++)
				{
					E.add(data[x]);
					
				}
				
				E.remove(object1);
				//data = (E[])E.toArray();
				canRemove = false;// if remove is executed then reset remove
									// boolean

			}
			else
				System.err.println("IllegalStateExeption");
		}

	}

}
