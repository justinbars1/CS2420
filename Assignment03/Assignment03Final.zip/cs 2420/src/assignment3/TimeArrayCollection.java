package assignment3;


import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

public class TimeArrayCollection {
	private static Random rand;
	public static void main(String[] args)
	{
		rand = new Random();
		rand.setSeed(System.currentTimeMillis());
		int randomInt = randomInt();
		int numberOfItems = 20000;
		ArrayCollection<Integer> test1 = new ArrayCollection<Integer> ();
		ArrayList<Integer> test2 = new ArrayList<Integer>();
		IntegerComparator cmp = new IntegerComparator();

		
		for (int x = 0; x < numberOfItems; x++)
		{
			test1.add(randomInt);
			test2.add(randomInt);
			randomInt = randomInt();
		}
		//TODO: Write code to time your toSortedList, contains, and SearchUtil.binarySearch methods so you can plot the results.
		long startTime, midpointTime, stopTime;
	    startTime = System.nanoTime();
  	    while (System.nanoTime() - startTime < 1000000000) {}
	    long timesToLoop = 100;
	    startTime = System.nanoTime();
	    
	    for (long i = 0; i < timesToLoop; i++)
	    {
	    	//test1.contains(randomInt);// this is to test the contains method
			//SearchUtil.binarySearch(test2, 3, cmp);// this will test the binarySearch method
	    	test1.toSortedList(cmp);// this is not working!!!!!!!!
	    }
	    midpointTime = System.nanoTime();
	    for (long i = 0; i < timesToLoop; i++) { }
	    stopTime = System.nanoTime();
	    double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ timesToLoop;
	    double totalTime = (midpointTime - startTime) - (stopTime - midpointTime);
	    System.out.println("This method takes exactly " + averageTime + " NanoSeconds per loop");
	    System.out.println("This method takes exactly " + totalTime + " nanoSeconds");
	}

	

	public static Integer randomInt()
	{
		return new Integer(rand.nextInt());
	}

}
