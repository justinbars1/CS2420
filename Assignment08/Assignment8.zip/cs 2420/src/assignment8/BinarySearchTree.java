package assignment8;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.NoSuchElementException;

/**
 * 
 * @author Justin Bbarsketis & Aaron Smith
 *@version March 7, 2013
 * @param <Type>
 */
public class BinarySearchTree<Type extends Comparable<? super Type>> implements SortedSet<Type> {
	/*
	 * The very incomplete code for the tree itself
	 * Most of the interesting code in this file is in the private BinaryNode class.
	 * For assignment 8, you will create a much more complete tree class
	 */
	private BinaryNode root;
	private int size;
	private ArrayList<Type> list;
	
	public BinarySearchTree()
	{
		root = null;
		size = 0;
		list = new ArrayList<Type>();//we have a global array for every node tree to help with the toArray method
	}
	
	// And many more methods...
	
	// YOU CAN USE THE BELOW PRIVATE CLASS AS YOUR NODE FOR ASSIGNMENT 8
	/**
	 * Represents a general binary tree node. Each binary node contains
	 * data, a left child, and a right child, and a parent.
	 * 
	 * This would make a good node class for a BinarySearchTree implementation
	 * 
	 */
	private class BinaryNode {

		// Since the outer BST class declares <Type>, we can use it here without redeclaring it for BinaryNode
		Type data;
		BinaryNode left;
		BinaryNode right;

		// Adding a parent reference breaks the definition of a tree,
		// but some people find it makes BST management easier.
		// If you choose to use them, remember to update parent pointers
		// when adding/removing nodes!
		BinaryNode parent;

		/**
		 * Construct a new node with known children
		 * 
		 */
		public BinaryNode(Type _data, BinaryNode _left,
				BinaryNode _right) {
			data = _data;
			left = _left;
			right = _right;
		}

		/**
		 * Construct a new node with no children
		 * 
		 */
		public BinaryNode(Type _data) {
			this(_data, null, null);
		}

		/**
		 * Construct a new node with a known parent
		 * 
		 */
		public BinaryNode(Type _data, BinaryNode _parent)
		{
			this(_data, null, null);
			parent = _parent;
		}

		/**
		 * Getter method.
		 * 
		 * @return the node data.
		 */
		public Type getData() {
			return data;
		}

		/**
		 * Setter method.
		 * 
		 * @param _data
		 *          - the node data to be set.
		 */
		public void setData(Type _data) {
			data = _data;
		}

		/**
		 * Getter method.
		 * 
		 * @return the left child node.
		 */
		public BinaryNode getLeft() {
			return left;
		}

		/**
		 * Setter method.
		 * 
		 * @param _left
		 *          - the left child node to be set.
		 */
		public void setLeft(BinaryNode _left) {
			left = _left;
		}

		/**
		 * Getter method.
		 * 
		 * @return the right child node.
		 */
		public BinaryNode getRight() {
			return right;
		}

		/**
		 * Setter method.
		 * 
		 * @param _right
		 *          - the right child node to be set.
		 */
		public void setRight(BinaryNode _right) {
			right = _right;
		}

		/**
		 * Getter method.
		 * 
		 * @return the parent of this node.
		 */
		public BinaryNode getParent()
		{
			return parent;
		}

		/**
		 * Setter method.
		 * 
		 * @param _parent
		 *          - the parent node to be set.
		 */
		public void setParent(BinaryNode _parent)
		{
			parent = _parent;
		}

		/**
		 * Number of children
		 * Use this to help figure out which BST deletion case to perform
		 * 
		 * @return The number of children of this node
		 */
		public int numChildren()
		{
			int numChildren = 0;
			if(getLeft() != null)
				numChildren++;
			if(getRight() != null)
				numChildren++;
			return numChildren;
		}

		/**
		 * @return The leftmost node in the binary tree rooted at this node.
		 */
		public BinaryNode getLeftmostNode() {
			// Base case, done for you
			if(getLeft() == null)
				return this; // returns "this" node
			
			
			return this.getLeft().getLeftmostNode();//return the 
		}

		/**
		 * @return The rightmost node in the binary tree rooted at this node.
		 */
		public BinaryNode getRightmostNode() {
			// Base case, done for you
			if(getRight() == null)
				return this; // returns "this" node

			// FILL IN - do not return null
			return this.getRight().getRightmostNode();
		}

		/**
		 * @return The height of the binary tree rooted at this node. The height of a
		 * tree is the length of the longest path to a leaf node. Consider a tree with
		 * a single node to have a height of zero.
		 *  
		 * The height of a tree with more than one node is the greater of its two subtrees'
		 * heights, plus 1
		 */
		public int height() {
			if (this.getRight()== null && this.getLeft()== null)
				return 0;
			int heightLeft = 0;
			int heightRight = 0;
			
			heightLeft = this.getLeft().height();
			heightRight = this.getRight().height();
			if (heightLeft > heightRight)
				return heightLeft + 1;
			else
				return heightRight+1;
			
		}

		/**
		 * 
		 * This method applies to binary search trees only (not general binary trees).
		 * 
		 * @return The successor of this node.
		 *  
		 * The successor is a node which can replace this node in a case-3 BST deletion.
		 * It is either the smallest node in the right subtree,
		 * or the largest node in the left subtree.
		 */
		public BinaryNode getSuccessor() 
		{
			
			if (this.getRight() == null && this.getLeft() == null)
				return null;
			BinaryNode N = this.getRight();
			N = N.getLeftmostNode();
			return N;
		}
		public BinaryNode findClosestNode (Type data)
		{
			if (this.data.equals(data))
				return this;
			if (this.getLeft() == null && this.getRight() == null)
				return this;
			if (this.data.compareTo(data) < 0 && this.getRight() == null)
				return this;
			if (this.data.compareTo(data) > 0 && this.getLeft() == null)
				return this;
			if (this.data.compareTo(data) > 0)
			{
				return this.getLeft().findClosestNode(data);
			}
			else
				 return this.getRight().findClosestNode(data);
			
//			BinaryNode temp = null;
//			if (this.getLeft() == null && this.getRight() == null)
//				{
//				return this;
//				}
//			
//			
//			if (this.getLeft() == null && this.getRight().data.compareTo(data) > 0 )
//			{
//				return this.getRight();
//			}
//			else if (this.getRight() == null && this.getLeft().data.compareTo(data) < 0 )
//			{
//				return this.getLeft();
//			}

			
			
		}
		
	}
	
	@Override
	public boolean add(Type item) {
		Boolean added = false;
		
		if (item == null)
		{
			return added;
		}
		BinaryNode N = new BinaryNode(item);
		
		if (size == 0)
		{
			root = N;
			size++;
			N.setParent(null);
			return true;
		}
//		if (contains(item))
//			return added;
		BinaryNode closest = root.findClosestNode(item);
		if (closest.data.equals(item))
			return added;
		if (N.data.compareTo(closest.data) < 0)//if the data toAdd is greater then the node returned 
		{
			closest.setLeft(N);
			N.setParent(closest);
			size++;
			added = true;
		}
		else
		{
			closest.setRight(N);
			size++;
			N.setParent(closest);
			added = true;
		}
		return added;
			
		
	}

	@Override
	public boolean addAll(Collection<? extends Type> items) {
		if (items == null)
			return false;
		for (Type temp: items)
			add(temp);
		return true;
	}

	@Override
	public void clear() {
		root = null;
		size = 0;
		
	}

	@Override
	public boolean contains(Type item) {
		if (item == null || root == null)
			return false;
		boolean contains = false;
		BinaryNode N = root.findClosestNode(item);
		contains= N.data.equals(item);
		return contains;//if the closest nodes data found is equal to the item data
	}

	@Override
	public boolean containsAll(Collection<? extends Type> items) {
		boolean allFound = true;
		if (items == null || root == null)
			return false;
		for (Type temp: items)
		{
			if (temp == null)
				continue;
			if (!contains(temp))
				allFound = false;
		}
		return allFound;
	}

	@Override
	public Type first() throws NoSuchElementException {
		if (root == null)
			throw new NoSuchElementException();
		return root.getLeftmostNode().data;//return the lowest value
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	@Override
	public Type last() throws NoSuchElementException {
		if (root == null)
			throw new NoSuchElementException();
		return root.getRightmostNode().data;
	}

	@Override
	public boolean remove(Type item) {
		//case 1
		boolean removed = false;//boolean for determining if something was removed
		if (item == null || root == null)
			return false;
		if (size == 1 && root.data == item)//if removing the root node just set and return
		{
			root = null;
			size--;
			return true;
		}
		if (!contains(item))//if the item is not in the list, dont remove anything
			return false;
		BinaryNode N = root.findClosestNode(item);//find the node to delete
		if (N.numChildren()==0)//if there are no children perform casd1 deletion
			removed = case1(N);//set removed boolean to the results of the method call
		else if (N.numChildren()==1)//case 2
			removed = case2(N);
		else
			removed = case3(N);
		
		
		
		return removed;
	}
	/**
	 * This method performs a case1 deletion on the node
	 * @param closest the node to delete 
	 * @return if it was deleted
	 */
	private boolean case1(BinaryNode closest)
	{
		boolean removed = false;
		BinaryNode parent = closest.getParent();
		if (parent.data.compareTo(closest.data) > 0)//if the data of the parent is greater then the item to remove data, unrefrence its left link
			{
			parent.setLeft(null);//set remove boolean and size
			removed = true;
			size--;
			}
		else
		{
			parent.setRight(null);
			removed = true;
			size--;
		}
		
		
		return removed;
	}
	/**
	 * This method perfroms a case2 deletion
	 * @param closest the node to delete
	 * @return
	 */
	private boolean case2(BinaryNode closest)
	{
		boolean removed = false;
		BinaryNode parent = closest.getParent();
		if (closest.getRight() == null)//if the right node is null
		{
			parent.setLeft(closest.getLeft());//then reset the left node
			removed = true;
			size--;//decrease size of tree
		}
		else//else do the other
			{
			parent.setRight(closest.getRight());
			removed = true;
			size--;
			}
		return removed;
	}
	/**
	 * This method performs a case3 deletion
	 * @param closest
	 * @return
	 */
	private boolean case3(BinaryNode closest)
	{
		boolean removed = false;
		BinaryNode successor = closest.getSuccessor();
		closest.data = successor.data;//change data in the item to remove to the successors data but keep the refrences
		if (successor.getRight() != null && successor.getLeft() == null || successor.getLeft() != null && successor.getRight() == null)
			removed = case2(successor);
		else
			removed = case1(successor);//remove the successor, which is a case 1 removal
		return removed;
	}
	
	@Override
	public boolean removeAll(Collection<? extends Type> items) {
		if (items == null || root == null)
			return false;
		boolean allRemoved = true;
		for (Type temp: items)
			{
			if (temp == null)
				continue;
			if(!remove(temp))//if any of the items was not removed then change boolean to false
				allRemoved = false;
			}
		return allRemoved;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public ArrayList<Type> toArrayList() {
		traversal(root);//call helper method for traversal and storing items into the array
		return list;//return global array values
	}
	
	private void traversal (BinaryNode N)
	{
		if (N == null)//if N is null the base case is reached
			return;
		traversal(N.getLeft());//traverse all the way left
		list.add(N.data);//add data to the global array
		traversal(N.getRight());//traverse to the right
		
	}
	public void writeDot(String filename)
	{
		try {
			// PrintWriter(FileWriter) will write output to a file
			PrintWriter output = new PrintWriter(new FileWriter(filename));
			
			// Set up the dot graph and properties
			output.println("digraph BST {");
			output.println("node [shape=record]");
			
			if(root != null)
				writeDotRecursive(root, output);
			// Close the graph
			output.println("}");
			output.close();
		}
		catch(Exception e){e.printStackTrace();}
	}

	
	// Recursive method for writing the tree to  a dot file
	private void writeDotRecursive(BinaryNode n, PrintWriter output) throws Exception
	{
		output.println(n.data + "[label=\"<L> |<D> " + n.data + "|<R> \"]");
		if(n.left != null)
		{
			// write the left subtree
			writeDotRecursive(n.left, output);
			
			// then make a link between n and the left subtree
			output.println(n.data + ":L -> " + n.left.data + ":D" );
		}
		if(n.right != null)
		{
			// write the left subtree
			writeDotRecursive(n.right, output);
			
			// then make a link between n and the right subtree
			output.println(n.data + ":R -> " + n.right.data + ":D" );
		}
		
	}
	
}
