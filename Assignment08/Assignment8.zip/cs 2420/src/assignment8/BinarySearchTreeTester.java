package assignment8;

import static org.junit.Assert.*;

import java.util.ArrayList;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class BinarySearchTreeTester extends TestCase{
	BinarySearchTree<Integer> treeAverage;
	BinarySearchTree<Integer> treeSingle;
	BinarySearchTree<Integer> treeAddAll;
	BinarySearchTree<Integer> treeEmpty;
	ArrayList<Integer> list1;
	ArrayList<Integer> list2;
	@Before
	public void setUp() throws Exception {
		treeAverage= new BinarySearchTree<Integer>();
		treeSingle= new BinarySearchTree<Integer>();
		treeEmpty= new BinarySearchTree<Integer>();
		treeSingle.add(0);
		treeAverage.add(6);
		treeAverage.add(5);
		treeAverage.add(2);
		treeAverage.add(7);
		treeAverage.add(3);
		treeAverage.add(4);
		treeAverage.add(9);
		treeAverage.add(9);
		treeAverage.add(8);
		treeAverage.add(3);
		treeAverage.add(2);
		treeAverage.add(1);
		treeAverage.add(7);
		treeAverage.add(8);
		treeAverage.add(9);
		treeAverage.add(12);
		list1 = new ArrayList<Integer>();
		list1.add(5);list1.add(6);list1.add(1);list1.add(0);list1.add(20);list1.add(14);list1.add(11);
		list1.add(8);list1.add(1);list1.add(12);list1.add(7);
		list2 = new ArrayList<Integer>();
		list2.add(9);list2.add(4);list2.add(8);list2.add(3);
		treeAddAll = new BinarySearchTree<Integer>();
		treeAddAll.addAll(list1);
	}

	@Test
	public void test() {
		//create dot file to check to see if data was formed correctly
		treeAverage.writeDot("treeAverage.dot");
		treeAddAll.writeDot("treeAddAll.dot");
		treeSingle.writeDot("treeSingle.dot");
		
	}
	public void testEmptyTree() {
		treeEmpty.clear();
		assertTrue(treeEmpty.size() == 0);
		assertTrue(treeEmpty.isEmpty() == true);
		assertEquals(treeEmpty.contains(0), false);
		assertEquals(treeEmpty.remove(0), false);
		assertEquals(treeEmpty.containsAll(list1), false);
		assertEquals(treeEmpty.removeAll(list1), false);
		ArrayList<Integer> temp = treeEmpty.toArrayList();
		assertEquals(temp.size(), 0);
	}
	public void testSingleTree() {
		assertEquals(treeSingle.size(), 1);
		assertEquals(treeSingle.contains(0), true);
		assertEquals(treeSingle.contains(1), false);
		assertEquals(treeSingle.isEmpty(), false);
		assertEquals((int)treeSingle.first(), 0);
		ArrayList<Integer> temp = treeSingle.toArrayList();
		assertEquals(temp.size(), 1);
		assertEquals(treeSingle.remove(1), false);
		assertEquals(treeSingle.remove(0), true);
		assertEquals(treeSingle.isEmpty(), true);
		treeSingle.add(0);
		ArrayList<Integer> temp1 = temp;
		
		
		assertEquals(treeSingle.containsAll(temp), true);
		temp1.add(1);
		assertEquals(treeSingle.containsAll(temp1), false);
		assertEquals(treeSingle.removeAll(temp1), false);
		temp.clear();
		temp.add(0);
		treeSingle.add(0);
		assertEquals(treeSingle.removeAll(temp), true);//remove all items from array
		
	}
	public void testAverageTree() {
		assertEquals(treeAverage.contains(2), true);
		assertEquals(treeAverage.contains(2), true);
		assertEquals(treeAverage.containsAll(list2), true);
		assertEquals(treeAverage.containsAll(list1), false);
		
		BinarySearchTree<Integer> temp = treeAverage;
		temp.removeAll(list2);
		assertEquals(temp.contains(2), true);
		assertEquals(temp.contains(9), false);
		assertEquals(temp.contains(4), false);
		assertEquals(temp.contains(8), false);
		assertEquals(temp.contains(3), false);
		assertEquals(treeAverage.remove(2), true);
		assertEquals(treeAverage.contains(2), false);
		treeAverage.writeDot("AverageRemovetwo.dot");
	}

}
