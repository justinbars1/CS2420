package extracredit;

public class MandelbrotWorker implements Runnable {

	// If given a single work assignment
	WorkAssignment singleAssignment;
	
	// If given a queue of assignments (shared by multiple threads)
	WorkQueue allAssignments;
	
	Display display;

	// For part 2
	/**
	 * Constructor taking a single work assignment
	 * @param assignment - the assignment to process
	 * @param d - the display (need to pass it to Mandelbrot render function)
	 */
	public MandelbrotWorker(WorkAssignment assignment, Display d) 
	{
		display = d;
		singleAssignment = assignment;
		
		// We aren't using a queue if we were given a single assignment
		allAssignments = null;
	}
	
	// For part 3
	/**
	 * Constructor taking a shared queue of work assignments
	 * @param assignments - the work queue from which to get assignments
	 * @param d - the display (need to pass it to Mandelbrot render function)
	 */
	public MandelbrotWorker(WorkQueue assignments, Display d)
	{
		display = d;
		// We aren't using a single assignment if we were given a queue
		singleAssignment = null;
		allAssignments = assignments;
	}

	public void run() 
	{
		
		//TODO: Fill in
		
		// ---------For part 2-----------
		// If singleAssignment is not null, render the single assignment
		// (call the static method Mandelbrot.render(...))
		// Then return
		if (singleAssignment != null)
		{
			Mandelbrot.render(singleAssignment, display);
			return;
		}

		while (allAssignments !=null)
		{  

			WorkAssignment temp = allAssignments.nextAssignment();
			if (temp != null)
				{
					Mandelbrot.render(temp, display);
					
				}
			else
				return;
			
		}
		//return;
		// ---------For part 3-----------
		// If allAssignments is not null, continuously request an assignment
		// from the allAssignments queue and render that assignment.
		// When the queue is out of assignments, a call 
		// to  return
		// Do not add thread synchronization code to this method,
		// synchronization will be handled from within the WorkQueue class
		
		
	}
}
