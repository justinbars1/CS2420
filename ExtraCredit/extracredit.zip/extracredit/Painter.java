package extracredit;

/**
 * 
 * This class allows for concurrent screen updating.
 *
 */
public class Painter implements Runnable 
{

	Display display;

	public Painter(Display d)
	{
		display = d;
	}

	/**
	 * Updates the image displayed by continuously calling display.updatePixels();
	 * Should refresh the image at a rate of 30Hz (30 times per second)
	 * Use Thread.sleep(long milis) to wait until the next update time
	 */
	public void run() 
	{
		while(true)
		{
			display.updatePixels();
			long sleepTime = 33;
			try {
				Thread.sleep(sleepTime);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		//TODO: Fill in
		
		/*
		 * call display.updatePixels() 30 times per second
		 * it is safe to use an infinite loop since when the window is closed,
		 * all threads will be terminated by System.exit()
		 */

	}
}
