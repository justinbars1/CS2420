package extracredit;

/**
 * DO NOT MODIFY THIS FILE
 * This class contains all the machinery for display the image and handling inputs
 */

// Tons of window and graphical imports
import java.awt.Frame; 
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.image.BufferedImage;
import java.awt.Color;
import java.awt.Graphics;
import java.io.File;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;


public class Display {

	private int imageSize = 800;
	private int maxIterations = 4096;

	private boolean drawing;

	private double xCenter;
	private double yCenter;
	private double zoom;
	private MandelbrotCanvas canvas;
	private Frame f;

	private MandelbrotViewer viewer;


	/**
	 * Creates the window and listeners
	 * 
	 * @param v - A reference to the MandelbrotViewer that has the methods for computing the mandelbrot
	 *            We need this reference in order to recompute the image when the mouse is clicked
	 */
	public  void initialize(MandelbrotViewer v) 
	{

		// Keep a reference to the viewer so we can tell it to redraw when the mouse is clicked
		viewer = v;

		// Start with a good center point to show the whole set
		xCenter = 0.0;
		yCenter = -.45;
		zoom = 1.0;


		canvas = new MandelbrotCanvas(imageSize, imageSize);
		resetImage();

		f = new Frame( "Mandelbrot" );
		f.add("Center", canvas);
		f.setSize(imageSize, imageSize);
		f.setVisible(true);

		// Handles window inputs (close, minimize, etc)
		f.addWindowListener(new MandelbrotWindowListener());

		// Handles mouse inputs
		f.addMouseListener(new MandelbrotMouseListener());

		// Handles keyboard inputs
		f.addKeyListener(new MandelbrotKeyListener());

	}

	/**
	 * Display the current value stored in every pixel
	 * (some may still be white, unprocessed)
	 * Call this method every 33 miliseconds from your Painter's run method.
	 */
	public void updatePixels()
	{
		canvas.enableDraw();
		canvas.paintComponent(canvas.getGraphics());
	}

	/**
	 * 
	 * @return one dimension of the image size (image is always square)
	 */
	public int getImageSize()
	{
		return imageSize;
	}

	/**
	 * 
	 * @return the X center of the "camera"'s position
	 */
	public  double getXCenter()
	{
		return xCenter;
	}

	/**
	 * 
	 * @return the Y center of the "camera"'s position
	 */
	public  double getYCenter()
	{
		return yCenter;
	}

	/**
	 * 
	 * @return the zoom of the "camera"
	 */
	public  double getZoom()
	{
		return zoom;
	}

	/**
	 * 
	 * Setters (analagous to getters above)
	 */
	public void setXCenter(double xc)
	{
		xCenter = xc;
	}

	public void setYCenter(double yc)
	{
		yCenter = yc;
	}

	public void setZoom(double z)
	{
		zoom = z;
	}

	/**
	 * 
	 * @return the max iterations used to compute the image
	 */
	public  int getMaxIterations()
	{
		return maxIterations;
	}

	/**
	 * 
	 * @return gets the BufferedImage which contains the pixels
	 */
	public  BufferedImage getImage()
	{
		return canvas.getImage();
	}

	/**
	 * Resets all pixels to white
	 */
	public void resetImage()
	{
		int[] white = new int[imageSize*imageSize];
		for(int i=0; i < imageSize*imageSize; i++)
			white[i] = 0xFFFFFF;
		canvas.getImage().setRGB(0, 0, imageSize, imageSize, white, 0, 1);
	}


	/**
	 * Writes a .png image file of the current image
	 * @param frameName
	 */
	public void toPng(String frameName)
	{
		BufferedImage image = canvas.getImage();

		try 
		{
			File outputfile = new File(frameName);
			ImageIO.write(image, "png", outputfile);
		}
		catch (IOException e) 
		{
			e.printStackTrace();
		}

	}

	/**
	 * 
	 * This class listens for input to the window controls (such as clicking the X button to close)
	 *
	 */
	private  class MandelbrotWindowListener extends WindowAdapter
	{
		public void windowClosing(WindowEvent we)
		{
			System.exit(0);
		}
	}

	/**
	 * 
	 * This class handles mouse input
	 *
	 */
	private class MandelbrotMouseListener implements  MouseListener
	{
		// When the mouse is clicked, center the image on that point 
		public void mouseClicked(MouseEvent mEvent) 
		{
			// Don't allow a click to interrupt the draw
			if(drawing)
				return;

			// Figure out the new center point
			double y = (((double)mEvent.getPoint().y / imageSize) * 2.0) - 1.0;
			double x = (((double)mEvent.getPoint().x / imageSize) * 2.0) - 1.0;
			x /= zoom;
			y /= zoom;
			xCenter += x; 
			yCenter += y;

			// Redraw the image
			viewer.draw();
		}

		public void mouseEntered(MouseEvent arg0) 
		{
			// No action required
		}

		public void mouseExited(MouseEvent arg0) 
		{
			// No action required

		}

		public void mousePressed(MouseEvent arg0) 
		{
			// No action required
		}

		public void mouseReleased(MouseEvent arg0) 
		{
			// No action required
		}
	}

	/**
	 * 
	 * This class handles keyboard input
	 *
	 */
	private  class MandelbrotKeyListener implements KeyListener
	{
		public void keyPressed(KeyEvent key)
		{
			// No action required
			return;
		}

		public void keyReleased(KeyEvent arg0) 
		{
			// No action required
			return;
		}

		public void keyTyped(KeyEvent key)
		{
			// Disable input until current frame is rendered
			if(drawing)
				return;

			// Certain keys don't change the image, no need to redraw
			boolean needsRedraw = true;

			switch(key.getKeyChar())
			{
			case '+': // zoom in
			case '=':
				zoom *= 2.5;
				break;
			case '-': // zoom out
			case '_':
				zoom /= 2.5;
				break;
			case 'd': // redraws the image with no change
				break;
			case 'p': // Print the camera info
				System.out.println("xCenter = " + xCenter + "; yCenter = " + yCenter + "; zoom = " + zoom + ";");
			default:
				needsRedraw = false;
			}

			if(needsRedraw)
				viewer.draw();
		}
	}

	/**
	 * 
	 * This class handles the graphical procedures for drawing the window
	 *
	 */
	@SuppressWarnings("serial")
	private class MandelbrotCanvas extends JPanel{

		private int width;
		private int height;
		private BufferedImage image;
		private boolean drawEnabled;

		public MandelbrotCanvas(int w, int h)
		{
			width = w;
			height = h;
			image = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
			drawEnabled = false;
		}

		public BufferedImage getImage()
		{
			return image;
		}

		public void enableDraw()
		{
			drawEnabled = true;
		}

		@Override
		public void paintComponent(Graphics g) 
		{
			if(drawEnabled)
				g.drawImage(image, 0, 0, Color.red, null);
		}

	}

}


