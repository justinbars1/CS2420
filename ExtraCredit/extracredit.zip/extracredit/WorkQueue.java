package extracredit;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;
import java.util.concurrent.Semaphore;

/**
 * 
 * Holds a queue of WorkAssignments
 * Access to the queue must be thread-safe
 * (it must prevent race-conditions, and must be deadlock-free)
 * 
 * Add member variables or methods as needed
 *
 */
public class WorkQueue 
{

	Queue<WorkAssignment> assignments;

	/**
	 * Creates a new work queue and fills it with the specified list of assignments.
	 * @param _assignments - the complete set of assignments
	 */
	public WorkQueue(ArrayList<WorkAssignment> _assignments)
	{
		assignments = new LinkedList<WorkAssignment>();
		assignments.addAll(_assignments);

	}

	/**
	 * 
	 * @return - The next assignment in the queue if there are any left, or
	 *         - null if there are no more assignments in the queue
	 */
	public WorkAssignment nextAssignment()
	{

		// TODO: Modify the below code to protect the accesss to the queue so that it is thread-safe
		Semaphore lock = new Semaphore(4);
		try {
			lock.acquire();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if(assignments.isEmpty())
			return null;
		
		WorkAssignment a = assignments.poll();
		lock.release();
		return a;
	}

}
