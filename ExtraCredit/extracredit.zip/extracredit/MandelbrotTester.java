package extracredit;

/**
 * 
 * Main class that runs the mandelbrot viewer
 *
 */
public class MandelbrotTester {

	public static void main(String[] args) throws InterruptedException
	{
		for(int i = 0; i < 20; i++){
		MandelbrotViewer viewer = new MandelbrotViewer();

		try 
		{
			// Part 1

			//viewer.basicViewer();
			
			// Part 2

			//viewer.staticParallelViewer();

			// Part 3
			// Experiment with different numbers of threads
			viewer.dynamicParallelViewer(8);

			
		}
		catch (InterruptedException e) 
		{
			e.printStackTrace();
		}
	}
	}
}
