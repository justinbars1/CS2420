package extracredit;

import java.awt.image.BufferedImage;


/**
 * DO NOT MODIFY THIS FILE
 * 
 * This class contains all the code that actually computes the mandelbrot image 
 *
 */
public class Mandelbrot
{

	Display display;

	
	// Renders the pixels within the rectangular region defined by regionToRender
	// Writes the computed pixel value to the BufferedImage in display
	public static long render(WorkAssignment regionToRender, Display display) 
	{
		// Represent a complex numbers z and c 
		// with a "real" part and an "imaginary" part
		double zreal;
		double zimag;
		double creal;
		double cimag;
		
		// "length" squared of z 
		double lengthsq;
		double temp;
		int k; // counts number of iterations

		// Get specific image info from the display
		// (center point, zoom, etc...)
		double horizontalCenter = display.getXCenter();
		double verticalCenter = display.getYCenter();
		double zoom = display.getZoom();
		int maxIters = display.getMaxIterations();
		BufferedImage image = display.getImage();

		long startTime = System.nanoTime();

		// Loop over every pixel in the region
		for(int col = regionToRender.getTopLeft().y; col <= regionToRender.getBorromRight().y; col++)
		{
			for(int row = regionToRender.getTopLeft().x; row <= regionToRender.getBorromRight().x; row++)
			{
				zreal = 0.0f;
				zimag = 0.0f;

				// First, map [0 .. width, height] down to [-1/zoom .. +1/zoom]
				// Compute the image rotated 90 degrees (I think it looks better that way)
				double y = (((double)col / image.getWidth()) * 2.0) - 1.0;
				double x = (((double)row / image.getHeight()) * 2.0) - 1.0;
				x /= zoom;
				y /= zoom;

				// Compute the mandelbrot in a square region around the center point
				creal = verticalCenter + x;
				cimag = horizontalCenter + y;

				k = 0;
				
				// This is just the basic mandelbrot set function
				do
				{
					temp = (zreal * zreal) - (zimag * zimag) + creal;
					zimag = (2.0f * zreal * zimag) + cimag;
					zreal = temp;
					lengthsq = (zreal * zreal) + (zimag * zimag);
					++k;
				}
				while(lengthsq < 4.f && k < maxIters);
				
				if(k==maxIters)
					k = 0;

				Color result = computeColor(k, maxIters);

				// Write the pixel we just computed to the image buffer
				// Draw the image rotated 90 degrees
				image.setRGB(col, row, (result.R << 16) + (result.G << 8) + (result.B));
			}
		}

		long stopTime = System.nanoTime();
		return stopTime - startTime;
		
	}


	// Color scheme
	// This converts the single numIterations value in to a color
	// Borrowed from :
	// http://www.fractalforums.com/programming/newbie-how-to-map-colors-in-the-mandelbrot-set/10/?wap2

	public static Color computeColor(int numIterations, int maxIterations)
	{
		if (numIterations == maxIterations) {
			return new Color(0, 0, 0);  /* In the set. Assign black. */
		} else if (numIterations < 64) {
			return new Color(numIterations * 2, 0, 0);    /* 0x0000 to 0x007E */
		} else if (numIterations < 128) {
			return new Color((((numIterations - 64) * 128) / 126) + 128, 0, 0);    /* 0x0080 to 0x00C0 */
		} else if (numIterations < 256) {
			return new Color((((numIterations - 128) * 62) / 127) + 193, 0, 0);    /* 0x00C1 to 0x00FF */
		} else if (numIterations < 512) {
			return new Color(255, (((numIterations - 256) * 62) / 255) + 1, 0);    /* 0x01FF to 0x3FFF */
		} else if (numIterations < 1024) {
			return new Color(255, (((numIterations - 512) * 63) / 511) + 64, 0);   /* 0x40FF to 0x7FFF */
		} else if (numIterations < 2048) {
			return new Color(255, (((numIterations - 1024) * 63) / 1023) + 128, 0);   /* 0x80FF to 0xBFFF */
		} else if (numIterations < 4096) {
			return new Color(255, (((numIterations - 2048) * 63) / 2047) + 192, 0);   /* 0xC0FF to 0xFFFF */
		} else {
			return new Color(255, 255, 0);
		}
	}

	/**
	 * 
	 * A simple class representing an RGB color
	 *
	 */
	private static class Color
	{
		int R;
		int G;
		int B;

		public Color(int r, int g, int b)
		{
			R = r;
			G = g;
			B = b;
		}
	}

}
