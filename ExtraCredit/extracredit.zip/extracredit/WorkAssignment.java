package extracredit;

import java.awt.Point;

/**
 * DO NOT MODIFY THIS CLASS
 * 
 * A simple class representing a work assignment
 * A work assignment is a rectangular region of the screen
 * (a set of pixels to render).
 * 
 * Represented by two points: topLeft and bottomRight
 *
 */
public class WorkAssignment 
{

	private Point topLeft;
	private Point bottomRight;

	public WorkAssignment(Point TL, Point BR)
	{
		topLeft = TL;
		bottomRight = BR;
	}


	public Point getTopLeft()
	{
		return topLeft;
	}

	public Point getBorromRight()
	{
		return bottomRight;
	}

}
