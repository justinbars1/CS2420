package extracredit;

import java.awt.Point;
import java.util.ArrayList;

/**
 * 
 * This class runs the mandelbrot viewer program
 * It creates the display window and starts the rendering routine
 * There are 3 different rendering routines: 
 * 	- basic single-threaded
 *  - parallel with a fixed number of threads and a fixed (static assignment per thread)
 *  - parallel with a variable number of threads and a work-queue assignment distribution 
 *
 */
public class MandelbrotViewer {

	public static final int BASIC = 1;
	public static final int STATIC = 2;
	public static final int DYNAMIC = 3;

	private int distributionStrategy;
	private int numThreads;
	private Display display;

	
	/**
	 * Runs the basic (single-threaded) viewer
	 * @throws InterruptedException - if interrupted while drawing
	 */
	public void basicViewer() throws InterruptedException
	{
		distributionStrategy = BASIC;
		runViewer();
	}

	/**
	 * Runs a viewer with 4 worker threads and a single fixed assignment per thread
	 * @throws InterruptedException - if interrupted while drawing
	 */
	public void staticParallelViewer() throws InterruptedException
	{
		distributionStrategy = STATIC;
		runViewer();
	}

	/**
	 * Runs a viewer with N parallel worker threads.
	 * Threads will pull assignments off of a work-queue
	 * @param n - number of simultaneous worker threads to run
	 * @throws InterruptedException - if interrupted while drawing
	 */
	public void dynamicParallelViewer(int n) throws InterruptedException
	{
		distributionStrategy = DYNAMIC;
		numThreads = n;
		runViewer();
	}

	/**
	 * "main" function that creates the display and dispatches the workers
	 *        based on configurations set by one of the above 3 functions
	 * @throws InterruptedException
	 */
	public void runViewer() throws InterruptedException 
	{
		display = new Display();
		display.initialize(this);

			Thread myThread = new Thread(new Painter(display));
			myThread.start();
		
		// TODO: Create and run a new Thread that runs a Painter
		//       You do not need to wait to join() the Painter Thread
		//       since we want it to run concurrently until the window is closed

		
		 draw();


	}

	/**
	 * Draws a single frame using one of three work assignment strategies
	 * Strategy is configured by one of the above *Viewer() methods
	 */
	public void draw()
	{
		display.resetImage();
		display.updatePixels();

		long startTime = System.nanoTime();
		switch(distributionStrategy)
		{
		case BASIC:
			drawSingleThreaded();
			break;
		case STATIC:
			drawStaticParallel();
			break;
		case DYNAMIC:
			drawDynamicParallel();
			break;
		default:
			System.out.println("Unknown draw type, exiting");
			System.exit(1);
			break;
		}
		long stopTime = System.nanoTime();
		display.updatePixels();
		//System.out.println("Total time: " + (stopTime - startTime) + "ns");
		System.out.println((stopTime - startTime));
	}

	/**
	 * Draw the mandelbrot using a single thread
	 * Creates one work assignment covering the whole image,
	 * then simply invokes the render method
	 */
	private void drawSingleThreaded()
	{
		WorkAssignment fullImage = 
				new WorkAssignment(
						new Point(0, 0), 
						new Point(display.getImageSize()-1, display.getImageSize()-1));

		Mandelbrot.render(fullImage, display);
	}

	/**
	 * Draws the mandelbrot using 4 threads
	 * Each thread has a fixed (static) assignment
	 * 
	 */
	private void drawStaticParallel()
	{

		ArrayList<WorkAssignment> assignments = badDistribution();

		Thread thread1 = new Thread(new MandelbrotWorker(assignments.get(0), display));
		Thread thread2 = new Thread(new MandelbrotWorker(assignments.get(1), display));
		Thread thread3 = new Thread(new MandelbrotWorker(assignments.get(2), display));
		Thread thread4 = new Thread(new MandelbrotWorker(assignments.get(3), display));
		thread1.start(); thread2.start();thread3.start(); thread4.start();
		//TODO: Fill in
		// Create 4 Threads, passing each one a different MandelbrotWorker
		// Each MandelbrotWorker should be assigned one of the 4 assignments 
		// from the "assignments" ArrayList above
		//  
		// Run all the treads simultaneously
		// After all threads have started, wait for them all to finish
		try {
			thread1.join();
			thread2.join();
			thread3.join();
			thread4.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


	/**
	 * Draws the mandelbrot using numThreads (member variable) Threads
	 * All threads will pull work assignments from a single work queue
	 */
	private void drawDynamicParallel()
	{
		//ArrayList<WorkAssignment> assignments = badDistribution();
		//ArrayList<WorkAssignment> assignments = betterDistribution();
		ArrayList<WorkAssignment> assignments = goodDistribution();

		WorkQueue wq = new WorkQueue(assignments);
//		long startTime1 = 0;
//		long startTime2 = 0;
//		long startTime3 = 0;
//		long startTime4 = 0;
//		long stopTime1 = 0;
//		long stopTime2 = 0;
//		long stopTime3 = 0;
//		long stopTime4 = 0;
		Thread[] threads = new Thread[numThreads];
		for (int x = 0; x < numThreads; x++)
		{
			threads[x] = new Thread(new MandelbrotWorker(wq, display));
//			if(x == 0)
//				startTime1 = System.nanoTime();
//			if(x == 1)
//				startTime2 = System.nanoTime();
//			if(x == 2)
//				startTime3 = System.nanoTime();
//			if(x == 3)
//				startTime4 = System.nanoTime();
			threads[x].start();
		}
		//for (Thread s: threads)
		for(int s = 0; s< threads.length; s++)
		{
			try {
				threads[s].join();
				//s.join();
//				if(s == 0)
//					stopTime1 = System.nanoTime();
//				if(s == 1)
//					stopTime2 = System.nanoTime();
//				if(s == 2)
//					stopTime3 = System.nanoTime();
//				if(s == 3)
//					stopTime4 = System.nanoTime();
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		//System.out.println((stopTime1 - startTime1)+"	"+(stopTime2 - startTime2)+"	"+(stopTime3 - startTime3)+"	"+(stopTime4 - startTime4));
		


	}


	/**
	 * Get an arrayList of workAssignments. 
	 * The assignments are poorly distributed (do not represent equal portions of work).
	 * 
	 * @return An ArrayList of workAssignments. 
	 *         The assignments must cover every pixel exactly once
	 */
	private ArrayList<WorkAssignment> badDistribution()
	{
		ArrayList<WorkAssignment> retVal = new ArrayList<WorkAssignment>();

		// Create 4 equal portions of the screen.
		// It is highly unlikely that each portion 
		// will represent an equal amount of work.
		// Furthermore, no more than 4 threads can utilize these assignments
		int imageSize = display.getImageSize();
		int oneQuarter = imageSize/4;
		for(int i=0; i < 4; i++)
		{
			Point topLeft = new Point(0, oneQuarter * i);
			Point bottomRight = new Point(imageSize - 1, oneQuarter * (i+1)-1);

			retVal.add(new WorkAssignment(topLeft, bottomRight));
		}

		return retVal;
	}



	/**
	 * Get an arrayList of workAssignments. 
	 * The assignments are moderately well-distributed 
	 * (should represent roughly equal portions of work).
	 * 
	 * @return An ArrayList of at least 8 workAssignments. 
	 *         The assignments must cover every pixel exactly once
	 */
	private ArrayList<WorkAssignment> betterDistribution()
	{
		ArrayList<WorkAssignment> retVal = new ArrayList<WorkAssignment>();
		
		int imageSize = display.getImageSize();
		int oneEighth = imageSize/8;
		for(int i=0; i < 8; i++)
		{
			Point topLeft = new Point(0, oneEighth * i);
			Point bottomRight = new Point(imageSize - 1, oneEighth * (i+1)-1);

			retVal.add(new WorkAssignment(topLeft, bottomRight));
		}

		return retVal;

	}



	/**
	 * Get an arrayList of workAssignments. 
	 * The assignments are well-distributed.
	 * (should be as close to equal portions of work as possible)
	 * 
	 * @return An ArrayList of at least 8 workAssignments. 
	 *         The assignments must cover every pixel exactly once
	 */
	private ArrayList<WorkAssignment> goodDistribution()
	{
ArrayList<WorkAssignment> retVal = new ArrayList<WorkAssignment>();
		
		int imageSize = display.getImageSize();
		int oneSixteenth = imageSize/32;
		for(int i=0; i < 32; i++)
		{
			Point topLeft = new Point(0, oneSixteenth * i);
			Point bottomRight = new Point(imageSize - 1, oneSixteenth * (i+1)-1);

			retVal.add(new WorkAssignment(topLeft, bottomRight));
		}

		return retVal;
	}

}
