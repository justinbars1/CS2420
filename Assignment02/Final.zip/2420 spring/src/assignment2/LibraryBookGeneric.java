package assignment2;
import java.util.GregorianCalendar;
public class LibraryBookGeneric<T> extends Book{

	
	
	
	T holder;
	Integer day, month, year;
	Boolean checkedIn;
	
	public LibraryBookGeneric(long _isbn, String _author, String _title) {
		super(_isbn, _author, _title);
		// TODO Auto-generated constructor stub
		
		
		
		
		
		
		
		
	}
//	public void statusChange ()
//	{
//		if (checkedIn == null)
//			checkedIn = false;
//		else if (checkedIn == false)
//			checkedIn = true;
//		else if (checkedIn == true)
//			checkedIn = false;
//		
//	}
	public GregorianCalendar getDueDate()
	{
		GregorianCalendar cal1 = new GregorianCalendar(year, month, day);
		
		if (checkedIn == true)//if it is checked into the library, return a null due date
			return null;
		
		return cal1;
	}
	public T getHolder()
	{
		
		if (checkedIn == null || checkedIn)//if it is checked into the library, return a null holder
			return null;
		
		return holder;
	}
	
	
	

}
