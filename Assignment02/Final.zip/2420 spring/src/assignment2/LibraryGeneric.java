package assignment2;

import java.io.File;
import java.io.FileNotFoundException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.Scanner;

/**
 * Class representation of a library (a collection of library books).
 * 
 */
public class LibraryGeneric<T> implements Comparator<T>{

  private ArrayList<LibraryBookGeneric<T>> library;

  public LibraryGeneric() {
    library = new ArrayList<LibraryBookGeneric<T>>();
  }

  /**
   * Add the specified book to the library, assume no duplicates.
   * 
   * @param isbn --
   *          ISBN of the book to be added
   * @param author --
   *          author of the book to be added
   * @param title --
   *          title of the book to be added
   */
  public void add(long isbn, String author, String title) {
    library.add(new LibraryBookGeneric<T>(isbn, author, title));
  }

  /**
   * Add the list of library books to the library, assume no duplicates.
   * 
   * @param list --
   *          list of library books to be added
   */
  public void addAll(ArrayList<LibraryBookGeneric<T>> list) {
    library.addAll(list);
  }

  /**
   * Add books specified by the input file. One book per line with ISBN, author,
   * and title separated by tabs.
   * 
   * If file does not exist or format is violated, do nothing.
   * 
   * @param filename
   */
  public void addAll(String filename) {
    ArrayList<LibraryBookGeneric<T>> toBeAdded = new ArrayList<LibraryBookGeneric<T>>();

    try {
      Scanner fileIn = new Scanner(new File(filename));
      int lineNum = 1;

      while (fileIn.hasNextLine()) {
        String line = fileIn.nextLine();

        Scanner lineIn = new Scanner(line);
        lineIn.useDelimiter("\\t");

        if (!lineIn.hasNextLong())
          throw new ParseException("ISBN", lineNum);
        long isbn = lineIn.nextLong();

        if (!lineIn.hasNext())
          throw new ParseException("Author", lineNum);
        String author = lineIn.next();

        if (!lineIn.hasNext())
          throw new ParseException("Title", lineNum);
        String title = lineIn.next();

        toBeAdded.add(new LibraryBookGeneric<T>(isbn, author, title));

        lineNum++;
      }
    } catch (FileNotFoundException e) {
      System.err.println(e.getMessage() + " Nothing added to the library.");
      return;
    } catch (ParseException e) {
      System.err.println(e.getLocalizedMessage()
          + " formatted incorrectly at line " + e.getErrorOffset()
          + ". Nothing added to the library.");
      return;
    }

    library.addAll(toBeAdded);
  }

  /**
   * Returns the holder of the library book with the specified ISBN.
   * 
   * If no book with the specified ISBN is in the library, returns null.
   * 
   * @param isbn --
   *          ISBN of the book to be looked up
   */
  public T lookup(long isbn) {
	T identifier = null;
    for (LibraryBookGeneric<T> b : library)
    {
    	if (b.getIsbn() == isbn)//if the isbn match each other then change string variable to holders name
    		
    			identifier = b.getHolder();
    }
    return identifier;
  }

  /**
   * Returns the list of library books checked out to the specified holder.
   * 
   * If the specified holder has no books checked out, returns an empty list.
   * 
   * @param holder --
   *          holder whose checked out books are returned
   */
  public ArrayList<LibraryBookGeneric<T>> lookup(T holder) {
    ArrayList<LibraryBookGeneric<T>> holderList = new ArrayList<LibraryBookGeneric<T>>(0);//create an empty list
    
    for (LibraryBookGeneric<T> b : library)
    {
		if (library.size() == 0)//if the library is empty return the empty list
			return holderList;
		
    	if (b.getHolder() == null || compare(b.getHolder(), holder) == 0)
    		if (b.getHolder() != null)//again if it is null then add to list anyways, or if holders match
    			holderList.add(b);
    		
    		
    			
    }
    
    
    return holderList;
  }

  /**
   * Sets the holder and due date of the library book with the specified ISBN.
   * 
   * If no book with the specified ISBN is in the library, returns false.
   * 
   * If the book with the specified ISBN is already checked out, returns false.
   * 
   * Otherwise, returns true.
   * 
   * @param isbn --
   *          ISBN of the library book to be checked out
   * @param holder --
   *          new holder of the library book
   * @param month --
   *          month of the new due date of the library book
   * @param day --
   *          day of the new due date of the library book
   * @param year --
   *          year of the new due date of the library book
   * 
   */
  public boolean checkout(long isbn, T holder, int month, int day, int year) {
    boolean isFound = false;
	
    for (LibraryBookGeneric<T> b : library)
	    {
    		if (b.checkedIn == null)//if its null change to true, we know its checked in if it hasnt been changed
    			b.checkedIn = true;
    		
	    	if (b.getIsbn() == isbn && b.checkedIn)//if the isbn match each other then change the objects month, day, year and holders to the method inputs
	    	{	isFound = true;
	    		b.day = day;
	    		b.month = month;
	    		b.year = year;//set the fields
	    		b.holder = holder;
	    		b.checkedIn = false;
	    	}
	    }
	  
	  
    return isFound;
  }

  /**
   * Unsets the holder and due date of the library book.
   * 
   * If no book with the specified ISBN is in the library, returns false.
   * 
   * If the book with the specified ISBN is already checked in, returns false.
   * 
   * Otherwise, returns true.
   * 
   * @param isbn --
   *          ISBN of the library book to be checked in
   */
  public boolean checkin(long isbn) {
    
	  boolean isFound = false;
	  
	    for (LibraryBookGeneric<T> b : library)
		    {
		    	if (b.getIsbn() == isbn && b.checkedIn == false)//if the isbn match each other then change the objects month, day, year and holders to null
		    		isFound = true;
		    		b.day = null;
		    		b.month = null;
		    		b.year = null;//set fields
		    		b.holder = null;
		    		b.checkedIn = true;
		    }
		  
		  
	    return isFound;
    
  }

  /**
   * Unsets the holder and due date for all library books checked out be the
   * specified holder.
   * 
   * If no books with the specified holder are in the library, returns false;
   * 
   * Otherwise, returns true.
   * 
   * @param holder --
   *          holder of the library books to be checked in
   */
  public boolean checkin(T holder) {
	  
	  boolean isFound = false;
	  for (LibraryBookGeneric<T> b : library)
	    {
		  if (b.getHolder() == null)
			  return isFound;
		  if (compare(b.getHolder(), holder) == 0)//if the holders match each other then change the objects month, day, year and holders to null
	    	{   isFound = true;
	    		b.day = null;
	    		b.month = null;
	    		b.year = null;
	    		b.holder = null;
	    		b.checkedIn = true;
	    	}
	    }
    return isFound;
  }

@Override
public int compare(Object left, Object right) {
	String T = left.getClass().getName();//get the type of class it is
	if (T.equals("String"))
	{//if its string use the compareTo
		String left1 = (String)left;//cast object into a string variable
		String right1 = (String)right;
		return left1.compareTo(right1);//return the results
	}
	if(T.equals("PhoneNumber"))
	{//if its phonenumber parse the string into an integer then compare
		PhoneNumber leftNumber = (PhoneNumber)left;
		PhoneNumber rightNumber = (PhoneNumber)right;
		String left2 = leftNumber.toString();
		String right2 = rightNumber.toString();//variables to hold all the casting required
		int final1 = Integer.parseInt(left2);
		int final2 = Integer.parseInt(right2);
		if(final1 > final2)
			return 1;
		else if (final1 == final2)//if statements to return -1 0 or 1 depending
			return 0;
		else if (final1 < final2)
			return -1;
		
	}
	return 0;
}
/**
 * Returns the list of library books, sorted by ISBN (smallest ISBN first).
 */
public ArrayList<LibraryBookGeneric<T>> getInventoryList() {
  ArrayList<LibraryBookGeneric<T>> libraryCopy = new ArrayList<LibraryBookGeneric<T>>();
  libraryCopy.addAll(library);

  OrderByIsbn comparator = new OrderByIsbn();

  sort(libraryCopy, comparator);

  return libraryCopy;
}

/**
 * Returns the list of library books, sorted by author
 */
public ArrayList<LibraryBookGeneric<T>> getOrderedByAuthor() {
   

	ArrayList<LibraryBookGeneric<T>> overDueList = new ArrayList<LibraryBookGeneric<T>>(0);
	
	if( library.size() == 0 || library == null)//if library is empty or null return empty list
		return overDueList;
	overDueList = library;//set new lsit to library
	
	
			Comparator<LibraryBookGeneric<T>> c = new OrderByAuthor();//import comparator
		  for (int i = 0; i < overDueList.size() - 1; i++) {
			    int j, minIndex;//sort by swapping using the comparator
			    for (j = i + 1, minIndex = i; j < overDueList.size(); j++)
			      if ((c.compare(overDueList.get(j), overDueList.get(minIndex)) < 0))
			    	  minIndex = j;
			    LibraryBookGeneric<T> temp = overDueList.get(i);
			    overDueList.set(i, overDueList.get(minIndex));
			    overDueList.set(minIndex, temp);
	
		  }
  return overDueList;
}

/**
 * Returns the list of library books whose due date is older than the input
 * date. The list is sorted by date (oldest first).
 *
 * If no library books are overdue, returns an empty list.
 */
public ArrayList<LibraryBookGeneric<T>> getOverdueList(int month, int day,int year) {

	GregorianCalendar cal = new GregorianCalendar(year, month, day);
	GregorianCalendar cal2;
	ArrayList<LibraryBookGeneric<T>> overDueList = new ArrayList<LibraryBookGeneric<T>>(0);
	if( library.size() == 0 || library == null)
		return overDueList;
	for( LibraryBookGeneric<T> temp : library)
	{
		if(temp.year == null)//if attributes are null exit out of for loop
			continue;
		cal2 = new GregorianCalendar(temp.year, temp.month, temp.day);//create new calender based off of inputs
		if (cal.compareTo(cal2) < 0)
		{
			overDueList.add(temp);//add all overdue items to new list
		}
	
	}
			Comparator<LibraryBookGeneric<T>> c = new OrderByDueDate();//import comparator
		  for (int i = 0; i < overDueList.size() - 1; i++) {
			    int j, minIndex;//swap sort with new comparator
			    for (j = i + 1, minIndex = i; j < overDueList.size(); j++)
			      if ((c.compare(overDueList.get(j), overDueList.get(minIndex)) < 0))
			    	  minIndex = j;
			    LibraryBookGeneric<T> temp = overDueList.get(i);
			    overDueList.set(i, overDueList.get(minIndex));
			    overDueList.set(minIndex, temp);
	
		  }
  return overDueList;//we resued this method, ignore variable names
}



/**
 * Performs a SELECTION SORT on the input ArrayList. 
 *    1. Find the smallest item in the list. 
 *    2. Swap the smallest item with the first item in the list. 
 *    3. Now let the list be the remaining unsorted portion 
 *       (second item to Nth item) and repeat steps 1, 2, and 3.
 */
private static <ListT> void sort(ArrayList<ListT> list,Comparator<ListT> c) {
  for (int i = 0; i < list.size() - 1; i++) {
    int j, minIndex;
    for (j = i + 1, minIndex = i; j < list.size(); j++)
      if (c.compare(list.get(j), list.get(minIndex)) < 0)
        minIndex = j;
    ListT temp = list.get(i);
    list.set(i, list.get(minIndex));
    list.set(minIndex, temp);
  }
}

/**
 * Comparator that defines an ordering among library books using the ISBN.
 */
protected class OrderByIsbn implements Comparator<LibraryBookGeneric<T>> {

  /**
   * Returns a negative value if lhs is smaller than rhs. Returns a positive
   * value if lhs is larger than rhs. Returns 0 if lhs and rhs are equal.
   */
  public int compare(LibraryBookGeneric<T> lhs,
      LibraryBookGeneric<T> rhs) {
    return (int) (lhs.getIsbn() - rhs.getIsbn());
  }
}

/**
 * Comparator that defines an ordering among library books using the author,  and book title as a tie-breaker.
 */
protected class OrderByAuthor implements 
Comparator<LibraryBookGeneric<T>> {

	@Override
	public int compare(LibraryBookGeneric<T> o1, LibraryBookGeneric<T> o2) {
		String authorLeft, authorRight, titleLeft, titleRight;
		authorLeft = o1.getAuthor();
		authorRight = o2.getAuthor();//set variables cast to strings
		titleLeft = o1.getTitle();
		titleRight = o2.getTitle();
		if (authorLeft.compareTo(authorRight) == 0)//if they are equal
			return titleLeft.compareTo(titleRight);//return based off title
		else
			return authorLeft.compareTo(authorRight);//if not compare based off author
		
	}

  // FILL IN
}

/**
 * Comparator that defines an ordering among library books using the due date.
 */
protected class OrderByDueDate implements Comparator<LibraryBookGeneric<T>> {

	public int compare(LibraryBookGeneric<T> o1, LibraryBookGeneric<T> o2) {
		GregorianCalendar cal1 = new GregorianCalendar(o1.year, o1.month, o1.day);
		GregorianCalendar cal2 = new GregorianCalendar(o1.year, o1.month, o1.day);
		//set calenders
		 return cal1.compareTo(cal2);//return results with gregarion compare method

	}

  // FILL IN
}


}
