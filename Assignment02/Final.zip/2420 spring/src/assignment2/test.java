package assignment2;

public class test {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Book Book1 = new Book(2, "x", "x");
		Book Book2 = new Book(2, "x", "x");
		Book Book3 = new Book(2, "y", "x");
		System.out.println(Book1.equals(Book3));
		
	}

}
