package assignment6;

import java.util.NoSuchElementException;
/**
 * 
 * @author Justin Barsketis & Aaron Smith
 *@version 2/20/13
 * @param <E>
 */
public class MyLinkedList<E> implements List<E>{
	
	int size; // global variable for the size of the list
	Node<E> head, tail;
	
	public MyLinkedList()
	{
		size = 0;
		head = null;//construct variables for the list, we need a size head and tail for doubly linked
		tail = null;
		
		
	}
	private class Node<T>//private class within linked list class to handle the nodes
	{
		Node<T> next, prev;
		T data;
		public Node( T d)//each node contains prev, next and data
		{
			data = d;//only data needs to be set, the method calling them will handle prev and next
			

		}
	}
	/**
	 * Inserts a Node between two items
	 */
	private void insertNode (Node<E> left, Node<E> middle, Node<E> right)
	{
		
		if (size == 0)//if the size is zero then set up head and tail to new node
		{
			head = middle;
			tail = middle;
			return;
		}

		if (left != null)
			left.next = middle;
		if (right != null)
			right.prev = middle;
		middle.next = right;
		middle.prev = left;
	}
	/**
	 * This method inserts a node at the end of the list
	 * @param end the last node in the list, aka the tail
	 * @param toInsert the node to be inserted at the end
	 */
	private void insertAtEnd (Node<E> end, Node<E> toInsert)
	{
		toInsert.prev = end;
		end.next = toInsert;//reset the tail
		tail = toInsert;
		
		
		
		
	}
	/**
	 * Removes a node from the list
	 * @param left the left node thats linked to the right
	 * @param middle the node to be inserted between
	 * @param right
	 */
	private E removeNode (Node<E> left, Node<E> middle, Node<E> right)
	{
		left.next = right;
		right.prev = left;//unlink the middle node from the other and relink right to left
		middle.next = null;
		middle.prev = null;
		return middle.data;
	}
	
	/**
	 * Inserts the specified element at the beginning of the list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public void addFirst(E element) {

		add(0, element);//add element at position 0
	}
	/**
	 * Inserts the specified element at the end of the list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public void addLast(E o) {
		
		if (size == 1|| size == 0)//if the list only contains zero or one item then insert it at the size, aka position 1
		{
			add(size, o);
		}
		else
			add(size-1, o);//else it should be size - 1
		
	}
	/**
	 * Adds items to index provided
	 */
	@Override
	public void add(int index, E element) throws IndexOutOfBoundsException {
		if (index > size || index < 0)
			throw new IndexOutOfBoundsException();//throw exception if index is out of range
		if (size == 0)//if the list is empty then set nodes accordingly
		{
			Node<E> first = new Node<E>(element);
			head = first;//set head and tail to new node and increase size
			tail = first;
			size++;
			return;
		}
		if (size == 1)//if there is only one item in the list
		{
			Node<E> first = new Node<E>(element);
			if (index == 0)//if adding to the beginning
			{
				first.next = head;
				head = first;
				tail.prev = first;//link nodes
				size++;
				return;
			}
			else if (index == 1)//if adding to the end
			{
				first.prev = tail;
				tail = first;
				head.next = first;//link nodes
				size++;
				return;
			}
		}
		if (index == 0)//if adding to the beginning of the list but not a small list set nodes accordingly
		{
		Node<E> first = new Node<E>(element);
		first.next = head;
		head.next.prev = first;
		head = first;
		size++;
		return;
		}
		int x = 0;//if we get to this point then the index is not at the beginning or end on a small list
		Node<E> temp = head;
		Node<E> toAdd = new Node<E>(element);//create the new node
		while (x < index )//iterate through to the node
		{
			temp = temp.next;
			x++;
		}
		if (index+1 == size)//if adding to the end call insert at end
		{
			insertAtEnd(temp, toAdd);
		}
		else
			insertNode(temp.prev, toAdd, temp.next);//insert node at spot
		
		
		size++;//increase size
		
	}
	/**
	 * Returns the first element in the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public E getFirst() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		
		return head.data;//return the data from the first item
	}
	/**
	 * Returns the last element in the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public E getLast() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		
		return tail.data;//return the data from the last item
	}
	/**
	 * Returns the element at the specified position in the list.
	 * Throws IndexOutOfBoundsException if index is out of range (index < 0 || index >= size())
	 * O(N) for a doubly-linked list.
	 */
	@Override
	public E get(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size())
			throw new IndexOutOfBoundsException();//test exception
		int x = 0;
		Node<E> temp = head;//create a new node to iterate from set to the head
		if (index +1 == size)//if getting the last item just return the tail data
			return tail.data;
		while (x < index )//iterate through to the node
		{
			temp = temp.next;
			x++;
		}
		return temp.data;
	}
	/**
	 * Removes and returns the first element from the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public E removeFirst() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();//test exception
		

		E temp = remove(0);//remove element and return its value
		return temp;
	}
	/**
	 * Removes and returns the last element from the list.
	 * Throws NoSuchElementException if the list is empty.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public E removeLast() throws NoSuchElementException {
		if (size == 0)
			throw new NoSuchElementException();
		

		E temp = remove(size-1);//remove last item in the list
		return temp;
	}
	/**
	 * Removes and returns the element at the specified position in the list.
	 * Throws IndexOutOfBoundsException if index is out of range (index < 0 || index >= size())
	 * O(N) for a doubly-linked list.
	 */
	@Override
	public E remove(int index) throws IndexOutOfBoundsException {
		if (index < 0 || index >= size())
			throw new IndexOutOfBoundsException();
		
		int x = 0;
		Node<E> temp = head;
		while (x < index)//iterate through to the node
		{
			temp = temp.next;
			x++;
		}
		if (index == 0 && size ==1)//if list is empty reset tail and head
		{
			E temp1 = head.data;
			head = null;
			tail = null;
			size--;
			return temp1;
		}
		if (index == 0)//if removing the first item in the list set head accordingly
		{
			E data = temp.data;
			head.next.prev = null;
			head = head.next;
			size--;
			return data;
			
			
		}
		if (index +1 == size)//if adding to the end set tail accordingly
		{
			E data = temp.data;
			tail = tail.prev;
			tail.next = null;
			size--;
			return data;
			
		}
		size--;//else call remove node
		return removeNode(temp.prev, temp, temp.next);
	}
	/**
	 * Returns the index of the first occurrence of the specified element in the list, 
	 * or -1 if this list does not contain the element.
	 * O(N) for a doubly-linked list.
	 */
	@Override
	public int indexOf(E element) {
		Node<E> temp = head;//set node to iterate with to the head
		for (int x = 0 ; x <= size; x++)//start iterating
		{
		if (temp.data.equals(element))//return index if it is found
			return x;
		temp = temp.next;
		
		}
		
		return -1;
	}
	/**
	 * Returns the index of the last occurrence of the specified element in this list, 
	 * or -1 if this list does not contain the element.
	 * O(N) for a doubly-linked list.
	 */
	@Override
	public int lastIndexOf(E element) {
		Node<E> temp = tail;//perform same iteration but starting at the end
		for (int x = size-1 ; x >= 0; x--)
		{
		if (temp.data.equals(element))//if item is found return x
			return x;
		temp = temp.prev;
		
		}
		
		return -1;
	}
	/**
	 * Returns the number of elements in this list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public int size() {
		
		return size;
	}
	/**
	 * Returns true if this collection contains no elements.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public boolean isEmpty() {
		
		return (size == 0);
	}
	/**
	 * Removes all of the elements from this list.
	 * O(1) for a doubly-linked list.
	 */
	@Override
	public void clear() {
		if (size == 0)
			return;
		head = null;//reset all values, aka unlink first node so collector collects it
		tail = null;
		size = 0;
		
	}
	/**
	 * Returns an array containing all of the elements in this list in proper sequence 
	 * (from first to last element).
	 * O(N) for a doubly-linked list.
	 */
	@Override
	public Object[] toArray() {
		Object[] temp = new Object[size];//create new array of object of right size
		if (size == 0)
			return temp;//return the array if the size is 0
		Node<E> tempNode = head;
		for (int x = 0; x < size; x++)//iterate through the nodes
		{
			temp[x] = (Object)tempNode.data;//copy over object into new array
			tempNode = tempNode.next;
		}
		return temp;
	}

}
