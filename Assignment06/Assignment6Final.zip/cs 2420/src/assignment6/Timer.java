package assignment6;


import java.util.ArrayList;
import java.util.Random;

public class Timer {
    private static Random rand;
    public static void main(String[] args)
    {
        int size = 0;
        
        rand = new Random();
        rand.setSeed(System.currentTimeMillis());
        int randomInt = randomInt();
        int numberOfItems = 20000;
        ArrayList<Integer> testArrayList = new ArrayList<Integer>(numberOfItems);


        MyLinkedList<Integer> testMyLinked = new MyLinkedList<Integer>();

        
        for (int x = 0; x < numberOfItems; x++)
        {
        	testArrayList.add(randomInt);
        	testMyLinked.addLast(randomInt);
        	
        }
        for(size = 0; size <= 1000000; size+=100000)
        {
        long startTime, midpointTime, stopTime;
        startTime = System.nanoTime();
          while (System.nanoTime() - startTime < 1000000000) {}
        long timesToLoop = 10000;
        startTime = System.nanoTime();
        
        for (long i = 0; i < timesToLoop; i++)
        {
        	
        	//testMyLinked.addFirst(randomInt); // Testing the Linked List addFirst method.
        	//testArrayList.add(0, randomInt); // Testing the ArrayList add at the first.
        	//testMyLinked.get((int)Math.random()); //Testing the Linked List get method.
        	//testArrayList.remove(0); // Testing the ArrayList get method.
        }
        midpointTime = System.nanoTime();
        for (long i = 0; i < timesToLoop; i++) { }
        stopTime = System.nanoTime();
        double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ timesToLoop;
        //double totalTime = (midpointTime - startTime) - (stopTime - midpointTime);
        System.out.println(size + "	" +averageTime);
        //System.out.println("This method takes exactly " + totalTime + " nanoSeconds");
        }
        }

    

    public static Integer randomInt()
    {
        return new Integer(rand.nextInt());
    }

}