package assignment6;

import java.util.NoSuchElementException;

import junit.framework.TestCase;

import org.junit.Before;
import org.junit.Test;

public class MyLinkedListTest extends TestCase{

	MyLinkedList<Integer> listSingle = new MyLinkedList<Integer>();
	
	MyLinkedList<Integer> listNull = new MyLinkedList<Integer>();
	MyLinkedList<Integer> listSmall = new MyLinkedList<Integer>();
	MyLinkedList<Integer> listAverage = new MyLinkedList<Integer>();
	
	@Before
	public void setUp() throws Exception 
	{
	
	listAverage.add(0, 0);
	listAverage.addLast(1);
	listAverage.addLast(2);
	listAverage.addLast(3);listAverage.addLast(4);
	listAverage.addLast(5);listAverage.addLast(6);listAverage.addLast(7);listAverage.addLast(8);listAverage.addLast(9);
	listSmall.addFirst(1);
	listSmall.addLast(2);
		
		
		
	}

	@Test
	
	public void testEmptyList()
	{
		listNull.clear();
		  try {
			    listNull.remove(0);
			  } catch (IndexOutOfBoundsException e) {
			    assertTrue(true);
			  }
		  try {
			    listNull.removeFirst();
			  } catch (NoSuchElementException e) {
			    assertTrue(true);
			  }
		  try {
			    listNull.removeLast();
			  } catch (NoSuchElementException e) {
			    assertTrue(true);
			  }
		  try {
			    listNull.get(0);
			  } catch (IndexOutOfBoundsException e) {
			    assertTrue(true);
			  }
		  try {
			    listNull.getFirst();
			  } catch (NoSuchElementException e) {
			    assertTrue(true);
			  }
		  try {
			    listNull.getLast();
			  } catch (NoSuchElementException e) {
			    assertTrue(true);
			  }
		Object[] test = listNull.toArray();
		assertEquals(test.length, 0);
		
		assertEquals(listNull.size(), 0); //size should be 0
		assertEquals(listNull.isEmpty(), true); //should be empty
	}
	public void testSingleItemList()
	{
		listSingle.add(0, 1);
		assertEquals(listSingle.get(0), listSingle.getFirst());//getfirst and get 0 should be equal
		assertEquals(listSingle.get(0), listSingle.getLast());//get first and get last should be equal
		assertEquals(0, listSingle.indexOf(1));//index should be zero of one
		assertEquals(listSingle.indexOf(1), listSingle.lastIndexOf(1));//index should be zero of both
		assertEquals(listSingle.size(), 1); //size should be one
		
		listSingle.removeFirst();//testing remove first
		assertEquals(listSingle.size(), 0); //size should be 0
		assertEquals(listSingle.isEmpty(), true); //should be empty
		
		listSingle.add(0, 1);listSingle.clear();//testing clear
		assertEquals(listSingle.size(), 0); //size should be 0
		assertEquals(listSingle.isEmpty(), true); //should be empty
		
		listSingle.add(0, 1);
		listSingle.removeLast();
		assertEquals(listSingle.size(), 0); //size should be 0
		assertEquals(listSingle.isEmpty(), true); //should be empty
		
		listSingle.add(0, 1);
		int int1 = listSingle.getFirst();
		int int2 = listSingle.getLast();
		assertEquals(int1, int2);
		
	}
	public void testSmallItemList()
	{
	listSmall.remove(0);
	assertEquals((int)listSmall.get(0), 2);
	listSmall.addFirst(1);
	listSmall.removeFirst();
	listSmall.addLast(3);
	listSmall.removeLast();
	assertEquals((int)listSmall.getFirst(), 2);
	listSmall.addLast(3);
	assertEquals((int)listSmall.getFirst(), 2);
	assertEquals((int)listSmall.getLast(), 3);
	}
	public void testAverageListAdd()
	{
		listAverage.addLast(10);
		assertEquals(10, (int)listAverage.get(10));
		assertEquals(listAverage.size(), 11);
	}
	public void testAverageListAddFirst()
	{
		listAverage.addFirst(-1);
		assertEquals(-1, (int)listAverage.get(0));
		assertEquals(listAverage.size(), 11);
	}
	public void testAverageListAddLast()
	{
		listAverage.addLast(10);
		assertEquals(10, (int)listAverage.get(10));
		assertEquals(listAverage.size(), 11);
	}
	public void testAverageListClear()
	{
		listAverage.clear();
		assertEquals(listAverage.size(), 0); //size should be 0
		assertEquals(listAverage.isEmpty(), true); //should be empty
		
	}
	public void testAverageListget()
	{
		assertEquals(listAverage.get(0), listAverage.getFirst());
		assertEquals(listAverage.get(9), listAverage.getLast());
		
	}
	public void testAverageListindexOf()
	{
		assertEquals(listAverage.indexOf(6), 6);
		assertEquals(listAverage.indexOf(9), 9);
		assertEquals(listAverage.indexOf(0), 0);
	}
	public void testAverageListlastIndexOf()
	{
		assertEquals(listAverage.lastIndexOf(5), 5);
		assertEquals(listAverage.lastIndexOf(9), 9);
		assertEquals(listAverage.lastIndexOf(0), 0);
		listAverage.addFirst(9);
		assertEquals(listAverage.lastIndexOf(9), 10);
		
		
	}
	public void testAverageListremove()
	{
		listAverage.remove(0);
		assertEquals((int)listAverage.get(0), 1);
		listAverage.remove(8);
		assertEquals((int)listAverage.get(7), 8);
		listAverage.remove(5);
		assertEquals((int)listAverage.get(5), 7);
		
	}
	public void testAverageListremoveFirstandLast()
	{
		listAverage.removeFirst();
		listAverage.removeLast();
		assertEquals((int)listAverage.getFirst(), 1);
		assertEquals((int)listAverage.getLast(), 8);
		listSmall.removeFirst();
		listSmall.removeLast();
		assertEquals(listSmall.isEmpty(), true);
	}
	public void testAverageListtoArray()
	{
		Object[] tester = {0,1,2,3,4,5,6,7,8,9};
		Object[] tester2 = listAverage.toArray();
		assertEquals(tester[0], tester2[0]);
		assertEquals(tester[2], tester2[2]);
		assertEquals(tester[4], tester2[4]);
		assertEquals(tester[6], tester2[6]);
		assertEquals(tester[7], tester2[7]);
		assertEquals(tester[9], tester2[9]);
		
	}
	
	

}
	
