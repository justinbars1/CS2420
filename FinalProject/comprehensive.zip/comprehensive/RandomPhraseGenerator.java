package comprehensive;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/**
 * @author Justin Barsketis & Aaron Smith
 * 
 */

public class RandomPhraseGenerator {

	static HashMap<String, ArrayList<String>> theMap = new HashMap<String, ArrayList<String>>();

	/**
	 * @param number of phrases to be generated
	 */


	public static void main(String[] args) {
		String pathName = args[0];//path name of the grammar file
		int numberOfPhrases = Integer.parseInt(args[1]);
		dotGFile(pathName);
		for (int x = 0; x < numberOfPhrases; x++)
		{
		System.out.println(phraseCreator());// This will need to be commented out for timing test
			//phraseCreator();// Use this code while running the timing test.
		}
		
	}
	/**
	 * 
	 * 
	 */
	public static String phraseCreator ()
	{
		StringBuilder sentence = new StringBuilder();
		sentence.append(randomString(theMap.get("<start>")));
		while (sentence.indexOf("<") != -1)
		{
		int FB = sentence.indexOf("<");
		int SB = sentence.indexOf(">");
		
		String name = (String) sentence.substring(FB, SB+1);
		if(SB > FB)
			sentence.replace(FB, SB+1, (String) randomString(theMap.get(name)));
			
		}
		
		
		return sentence.toString();
	}
	/**
	 * this method returns a random object from our string arrays
	 */
	public static Object randomString (ArrayList<String> temp)
	{
		 Random randomNumber = new Random();
		 int index = randomNumber.nextInt(temp.size());
		return temp.get(index);
	}
	/**
	 * @param the function will take in the name of a .g file extension 
	 * 
	 */
	public static  void dotGFile(String inputFile){
		BufferedReader input = null;

		try {
			input = new BufferedReader(new FileReader(inputFile));
			while(input.ready()){
				String line = input.readLine();
				if (line.compareTo("{") ==0)
					addToHashMap(input);
			}  
		}
		catch (FileNotFoundException e) {
			System.out.println("yepp");
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}


	}
	/**
	 * This method is called once a open bracket is reached. It add all the terminals to the hashMap
	 * @param input the reader to be read from
	 */
	public static void addToHashMap (BufferedReader input)
	{
		try {
		String terminalName = input.readLine();
		theMap.put(terminalName, new ArrayList<String>());
		ArrayList<String> temp = (ArrayList<String>) theMap.get(terminalName);
		
			while(input.ready()){

				String current = input.readLine();
				if (current.compareTo("}") == 0)//if the end bracket is reached, exit method
					return;
				temp.add(current);

			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}



}
