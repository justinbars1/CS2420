package comprehensive;


public class tester {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		String[] temp = {"super_simple.g", "10"};
		RandomPhraseGenerator.main(temp);

	
	
	

	
	}
	

}
