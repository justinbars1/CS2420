package comprehensive;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import assignment7.MyStack;

public class timer {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

	        int size;
	        for(size = 10; size <=200; size+=10)
	        { 
	    	    
	    		nonTerminal(size);
	    		nonTerminalsInProd(size);
	    		numberOfProduction(size);
	    		//"super_simple.g"

	        long startTime, midpointTime, stopTime;
	        startTime = System.nanoTime();
	          while (System.nanoTime() - startTime < 1000000000) {}
	        long timesToLoop = 10000;
	        startTime = System.nanoTime();
	        
	        for (long i = 0; i < timesToLoop; i++)
	        {
	    		//String[] temp = {"nonTerminal.g", "1"};
	    		//RandomPhraseGenerator.main(temp);
	        	//String[] temp = {"nonTerminalsInProd.g","1"};
	        	//RandomPhraseGenerator.main(temp);
	        	//String[] temp = {"numberOfProduction.g","1"};
	        	//RandomPhraseGenerator.main(temp);
	    		String[] temp = {"super_simple.g", ""+size};
	    		RandomPhraseGenerator.main(temp);
	        }
	        midpointTime = System.nanoTime();
	        for (long i = 0; i < timesToLoop; i++) { }
	        stopTime = System.nanoTime();
	        double averageTime = ((midpointTime - startTime) - (stopTime - midpointTime))/ timesToLoop;
	        System.out.println(size + "	" +averageTime/100);        
	        }

	    }



	private static void numberOfProduction(int pro) {
		
		  try {
			PrintWriter myFile = new PrintWriter((new FileWriter("numberOfProduction.g")));
			
			  for(int i = 1; i < pro; i++){ 
				  
				  if(i == 1){
					  myFile.println("{");
					  myFile.println("<start>");
					  myFile.println("<1>");
					  myFile.println("}");
					  myFile.println();
					  myFile.println("{");
					  myFile.println("<1>");
				  }
				  myFile.println(i);
			  }
			myFile.println("}");
			myFile.close();
		} catch (IOException e) {
			  {System.out.println("Error printing output File "+ e);}
			e.printStackTrace();
		}

	}



	/**
	 * This will make a file that is used for the amount of terminals in the file
	 * @param int number of items to be added to the file.
	 */
	private static void nonTerminal(int count){
		  try {
			  PrintWriter myFile = new PrintWriter((new FileWriter("nonTerminal.g")));
		
		  for(int i = 1; i < count; i++){ 
			  
			  if(i == 1){
				  myFile.println("{");
				  myFile.println("<start>");
				  myFile.println("<1>");
				  myFile.println("}");
				  myFile.println();
			  }

			  myFile.println("{");
			  myFile.println("<"+i+">");
			  myFile.print(i); myFile.println("<"+(i+1)+">");
			  myFile.println("}");
			  myFile.println();
			  
			  if(i+1 == count){
				  myFile.println("{");
				  myFile.println("<"+(i+1)+">");
				  myFile.println("0");
				  myFile.println("}");
			  }
			  

		  }
		  myFile.close();
		  } catch (IOException e) {
			  {System.out.println("Error printing output File "+ e);}
			  e.printStackTrace();
		}
	}
	/**
	 * this will add nonterminals in a product
	 * @param nonTermIN
	 */
	private static void nonTerminalsInProd(int nonTermIN){

		  try {
			PrintWriter myFile = new PrintWriter((new FileWriter("nonTerminalsInProd.g")));

				myFile.println("{");
				myFile.println("<start>");
				for(int j = 0; j < nonTermIN; j ++){
					 Random randomNumber = new Random();
					 int index = randomNumber.nextInt(3);
					myFile.print("<"+index+">");	
				}
				myFile.println();
				myFile.println("}");
				myFile.println();
				myFile.println("{");
				myFile.println("<"+0+">");
				myFile.println("zing");
				myFile.println("}");
				myFile.println();
				myFile.println("{");
				myFile.println("<"+1+">");
				myFile.println("ping");
				myFile.println("}");
				myFile.println();
				myFile.println("{");
				myFile.println("<"+2+">");
				myFile.println("plane");
				myFile.println("}");
				myFile.println();
				myFile.close();
		  } catch (IOException e) {
			  {System.out.println("Error printing output File "+ e);}
			e.printStackTrace();
		  }
	}

}
