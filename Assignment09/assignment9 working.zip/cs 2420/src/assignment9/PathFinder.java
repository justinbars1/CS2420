package assignment9;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.LinkedList;

public class PathFinder {

	static Graph maze = null;//a graph array to represent the data from the file
	static int[] startingPoint = new int[2];//an array to hold the starting point
	
	
	public static void solveMaze(String inputFile, String outputFile) {
		
		PathFinder solver = new PathFinder();
		BufferedReader input = null;
		int height = 0;//create a buffered reader and variables to hold the height and width
		int width = 0;
		
		String[] dimensions;
		
		  try

		  {
		  input = new BufferedReader(new FileReader(inputFile));
		  dimensions = input.readLine().split(" ");//try creating a buffered reader on the file
		  height = Integer.parseInt(dimensions[0]);
		  width = Integer.parseInt(dimensions[1]);//the height and width set accordingly
		  maze = solver.new Graph(width+1, height+1);//create a new graph with new dimensions
		  String line;//variable to hold the different lines
		  for (int y = 0; y < height; y++)//iterate through the height
			{
			  line = input.readLine();
			  
			  char[] temp = line.toCharArray();//read the lines putting the characters into arrays
			  
			  for (int x = 0; x < width; x++)//iterate throught the different characters
			  {
				  String s = Character.toString(temp[x]);//put into a string
				  if (s.compareTo("S") == 0)//if it is the starting point
					  {
					  startingPoint[0] = x;//set array
					  startingPoint[1] = y;
					  }
				  
				  maze.graph[x][y] = solver.new Node<String>(s, x, y);//create a new node of the object with data and location in the array
			  }
			}
		}catch (Exception e){System.out.println("Error, file not readable " + e);return;}

		   Node<String> goal = BFS();//connect nodes to the goal using private method
		   if (goal == null)//if goal is null then it was never reached
			   {
			   System.out.println("There is no solution");
			   }
		   else
		   {
			   Node<String> current = goal.cameFrom;
			   while (current != null && (((String) current.data).compareTo("S") != 0))//while the current node isnt null and not on starting point
			   {
				   current.data = ".";//replace the data with dots
				   current = current.cameFrom;//move back a node
			   }
			   
			   
		   }

		  try
		  {

			  PrintWriter output = new PrintWriter(new FileWriter(outputFile));

			  output.println(height + " " + width);//print the data to a new file with output file name

			  for (int y = 0; y < height; y++)
				  
			  {
				  
				  for (int x = 0; x < width; x++)//iterate through both x and y
				  {
					  if (maze.graph[x][y] == null)//if null replace with an x
						  output.print("x");
					  else
						  output.print(maze.graph[x][y].data);//print from the graph array
					
				  }
				  output.print('\n');//create new line with every y
			  }
			  
			  output.close();//close scanner

		  }catch(Exception e){System.out.println("Error printing output File "+ e);}
	
		  
	 
		  
	}
	public static Node<String> BFS()
	 {
		
		 
		 LinkedList<Node<String>> queue = new LinkedList<Node<String>>();
		 Node<String> start = maze.graph[startingPoint[0]] [startingPoint[1]];
		 
		 start.visited = true;
		 queue.push(start);
		 while (!queue.isEmpty())
		 {	
			 
			 Node<String> current = queue.pollLast();
			 if (current.data.compareTo("G")== 0)
				 return current;
			 Node<String> up = getUp(current);
			 if (!(up.data.equals("X")||up.visited == true))
				 {
				 up.visited = true;
				 up.cameFrom = current;
				 
				 queue.push(up);
				 }
			 Node<String> down = getDown(current);
			 if (!(down.data.equals("X")||down.visited == true))
				 {
				 down.visited = true;
				 down.cameFrom = current;
				 
				 queue.push(down);
				 }
			 Node<String> left = getLeft(current);
			 if (!(left.data.equals("X")||left.visited == true))
				 {
				 left.visited = true;
				 left.cameFrom = current;
				 
				 queue.push(left);
				 }
			 Node<String> right = getRight(current);
			 if (!(right.data.equals("X")||right.visited == true))
				 {
				 right.visited = true;
				 right.cameFrom = current;
				 
				 queue.push(right);
				 }
				 
			 
			 
		 }
		 return null;
	 }
	private class Node<T>
	{
		Node<String> cameFrom;//create nodes for all directions
		int locationX, locationY;
		String data;//create variable to hold the data
		Boolean visited = false;
		
		public Node(String value, int x, int y)
		{
			data = value;
			locationX = x;
			locationY = y;
			
		}
	}
	private class Graph
	{
		Node<String>[][] graph;
		@SuppressWarnings("unchecked")
		public Graph(int rows, int columns)
		{
			graph = new Node[rows][columns];
		}
	}
	
	
	private static Node<String> getUp(Node<String> current)
	{
		
		return maze.graph[current.locationX][current.locationY-1];
	}
	private static Node<String> getDown(Node<String> current)
	{
		return maze.graph[current.locationX][current.locationY+1];
	}
	private static Node<String> getLeft(Node<String> current)
	{
		return maze.graph[current.locationX-1][current.locationY];
	}
	private static Node<String> getRight(Node<String> current)
	{
		return maze.graph[current.locationX+1][current.locationY];
	}
}

